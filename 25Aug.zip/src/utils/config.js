// export const BASE_URL = "https://childcare-backend-production-14ca.up.railway.app/api";

// export const BASE_URL = "https://2lkmvcf8-5000.inc1.devtunnels.ms/api";  // LAKHAN

// export const BASE_URL = "https://3ktt3vxd-5000.inc1.devtunnels.ms/api"
// export const BASE_URL = "http://localhost:5000/api"
// export const BASE_URL = "https://3ktt3vxd-5000.inc1.devtunnels.ms/api"

// export const BASE_URL = "https://childcare-backend-production-14ca.up.railway.app/api"; 
    export const BASE_URL = "http://localhost:5000/api"; // Development URL for testing
