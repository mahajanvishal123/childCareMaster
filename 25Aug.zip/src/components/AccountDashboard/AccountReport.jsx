import React, { useEffect, useState, useRef } from 'react';
import * as echarts from 'echarts';
import { BarChart, XAxis, YAxis, Tooltip, CartesianGrid, Bar, ResponsiveContainer, Label } from 'recharts';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import html2pdf from 'html2pdf.js';
import { FaFile, FaFileAlt } from 'react-icons/fa';
import axios from 'axios'; // Added axios import
import { BASE_URL } from '../../utils/config';

const AccountReports = () => {
  const [activeTab, setActiveTab] = useState('monthly');
  const [selectedYear, setSelectedYear] = useState('2025');
  const [selectedMonth, setSelectedMonth] = useState('June');
  const [selectedFormat, setSelectedFormat] = useState('PDF');
  const [data, setData] = useState([
    { name: 'Oliver Wilson', dob: 'May 12, 2020', enroll: 'Jan 15, 2023', parent: 'Rebecca Wilson', phone: '(555) 123-4567', Staff: 'Emily Johnson', status: 'Active' },
    { name: 'Sophia Patel', dob: 'Aug 3, 2019', enroll: 'Sep 5, 2022', parent: 'Raj & Priya Patel', phone: '(555) 234-5678', Staff: 'Michael Rodriguez', status: 'Active' },
    { name: 'Lucas Green', dob: 'Jan 10, 2021', enroll: 'Feb 15, 2023', parent: 'Jason & Emma Green', phone: '(555) 345-6789', Staff: 'Sarah Williams', status: 'Inactive' },
    { name: 'Mia Carter', dob: 'Nov 8, 2018', enroll: 'Oct 3, 2022', parent: 'David & Lily Carter', phone: '(555) 456-7890', Staff: 'James Walker', status: 'Active' },
    { name: 'Liam Brown', dob: 'Dec 18, 2019', enroll: 'Jul 22, 2021', parent: 'John & Maria Brown', phone: '(555) 567-8901', Staff: 'Mary Lee', status: 'Active' },
    { name: 'Amelia Taylor', dob: 'Jun 25, 2020', enroll: 'Mar 12, 2022', parent: 'George & Alice Taylor', phone: '(555) 678-9012', Staff: 'John Smith', status: 'Provisionally Approved' },
    { name: 'Ethan White', dob: 'Feb 4, 2021', enroll: 'May 1, 2023', parent: 'Alex & Sofia White', phone: '(555) 789-0123', Staff: 'Olivia Martin', status: 'Inactive' }
  ]);

  const [staffList, setStaffList] = useState([]);
  const [loading, setLoading] = useState(true);

  const staffData = [
    {
      initials: "EB", name: "Emily Blackwell", email: "emily.blackwell@example.com", dob: "05/12/1988", courses: ["First Aid", "Child Development", "Safety"], qualifications: "Early Childhood Education, Child Psychology", approval: "Approved", immunizations: "Completed", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
    {
      initials: "JW", name: "James White", email: "james.white@example.com", dob: "09/11/1985", courses: ["CPR", "Safety"], qualifications: "Health and Safety Certification", approval: "Provisionally Approved", immunizations: "Completed", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
    {
      initials: "MR", name: "Maria Rodriguez", email: "maria.rodriguez@example.com", dob: "01/20/1990", courses: ["First Aid", "CPR"], qualifications: "Early Childhood Ed.", approval: "Approved", immunizations: "Pending", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
    {
      initials: "TS", name: "Thomas Smith", email: "thomas.smith@example.com", dob: "07/15/1982", courses: ["Safety"], qualifications: "Childcare License", approval: "Not Approved", immunizations: "Completed", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
    {
      initials: "AL", name: "Anna Lee", email: "anna.lee@example.com", dob: "03/05/1993", courses: ["CPR", "Child Development"], qualifications: "BA in Psychology", approval: "Approved", immunizations: "Completed", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
    {
      initials: "RW", name: "Ryan Wong", email: "ryan.wong@example.com", dob: "10/08/1986", courses: ["First Aid", "Safety"], qualifications: "B.Ed.", approval: "Provisionally Approved", immunizations: "Pending", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
    {
      initials: "KH", name: "Kiran Hegde", email: "kiran.hegde@example.com", dob: "04/14/1989", courses: ["CPR", "First Aid", "Child Development"], qualifications: "M.Ed.", approval: "Approved", immunizations: "Completed", documents: [
        { url: "/documents/emily-certificate.pdf", filename: "Emily_Certificate.pdf", name: "Certificate" },
        { url: "/documents/emily-id.pdf", filename: "Emily_ID.pdf", name: "ID Proof" },
        { url: "/documents/emily-license.pdf", filename: "Emily_License.pdf", name: "License" },
        { url: "/documents/emily-resume.pdf", filename: "Emily_Resume.pdf", name: "Resume" },
      ]
    },
  ];

  const reportList = [
    { icon: 'file-invoice', name: 'Monthly Income Statement', date: 'June 20, 2025' },
    { icon: 'chart-pie', name: 'Expense Breakdown', date: 'June 18, 2025' },
    { icon: 'chart-line', name: 'Cash Flow Analysis', date: 'June 15, 2025' },
    { icon: 'piggy-bank', name: 'Savings & Investment Report', date: 'June 10, 2025' },
    { icon: 'receipt', name: 'Tax Summary', date: 'June 5, 2025' }
  ];

  const reportRef = useRef();
  const summaryRef = useRef();
  const tableRef = useRef();

  const handleDownloadPDF = () => {
    const element = tableRef.current;
    const opt = {
      margin: 0.3,
      filename: 'staff-report.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
    };
    html2pdf().set(opt).from(element).save();
  };

  const handleTableReportDownload = (report) => {
    const fileName = `${report.name.replace(/\s+/g, "_")}_${selectedMonth}_${selectedYear}`;

    if (selectedFormat === "PDF") {
      const element = document.createElement("div");
      element.innerHTML = `
            <h2 style="color: #2ab7a9; font-family: sans-serif;">${report.name}</h2>
            <p><strong>Month:</strong> ${selectedMonth}</p>
            <p><strong>Year:</strong> ${selectedYear}</p>
            <p><strong>Last Generated:</strong> ${report.date}</p>
          `;

      html2pdf()
        .set({
          margin: 0.5,
          filename: `${fileName}.pdf`,
          image: { type: "jpeg", quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: "in", format: "letter", orientation: "portrait" }
        })
        .from(element)
        .save();
    } else if (selectedFormat === "CSV") {
      const csvContent = `Report Name,Month,Year,Generated\n"${report.name}",${selectedMonth},${selectedYear},${report.date}`;
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.setAttribute("download", `${fileName}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else if (selectedFormat === "Excel") {
      const excelContent = `
            <table border="1">
              <thead>
                <tr>
                  <th>Report Name</th>
                  <th>Month</th>
                  <th>Year</th>
                  <th>Generated</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>${report.name}</td>
                  <td>${selectedMonth}</td>
                  <td>${selectedYear}</td>
                  <td>${report.date}</td>
                </tr>
              </tbody>
            </table>
          `;
      const blob = new Blob([excelContent], { type: "application/vnd.ms-excel" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.setAttribute("download", `${fileName}.xls`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleDownloadReport = () => {
    const element = reportRef.current;
    const opt = {
      margin: 0.5,
      filename: `Monthly-Summary-${selectedMonth}-${selectedYear}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  };

  const handleDownloadSummaryPDF = () => {
    const element = summaryRef.current;
    const options = {
      margin: 0.3,
      filename: 'monthly-enrollment-summary.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(options).from(element).save();
  };

  const chartData = (() => {
    const monthMap = {};
    data.forEach(child => {
      const date = new Date(child.enroll);
      const month = date.toLocaleString('default', { month: 'short' });
      monthMap[month] = (monthMap[month] || 0) + 1;
    });
    return Object.keys(monthMap).map(month => ({
      month,
      count: monthMap[month]
    }));
  })();

  const fetchStaffList = () => {
    setLoading(true);
    axios.get(`${BASE_URL}/teachers`)
      .then((res) => {
        if (res.data) {
          const mapped = res.data.map((item) => ({
            id: item.user_id,
            initials: `${item.first_name[0] || ''}${item.last_name[0] || ''}`.toUpperCase(),
            name: `${item.first_name} ${item.last_name}`,
            email: item.email,
            dob: new Date(item.dob).toLocaleDateString(),
            courses: item.courses || [],
            qualifications: item.notes || "N/A",
            approval: item.cbc_status,
            immunizations: item.status,
            documents: [
              { url: item.photo, name: "Photo" },
              { url: item.medical_form, name: "Medical Form" },
              { url: item.credentials, name: "Credentials" },
              { url: item.cbc_worksheet, name: "CBC Worksheet" },
              { url: item.auth_affirmation_form, name: "Auth Affirmation" },
              { url: item.mandated_reporter_cert, name: "Mandated Reporter" },
              { url: item.preventing_sids_cert, name: "SIDS Cert" },
            ]
          }));
          setStaffList(mapped);
        }
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchStaffList();
  }, []);

  const staffChartData = (() => {
    const summary = {};
    staffList.forEach(staff => {
      const status = (staff.approval || '').toLowerCase();
      summary[status] = (summary[status] || 0) + 1;
    });
    return Object.keys(summary).map(status => ({
      status,
      count: summary[status]
    }));
  })();


  useEffect(() => {
    if (activeTab !== 'monthly') return;

    const chartDom = document.getElementById('monthly-summary-chart');
    if (chartDom) {
      const myChart = echarts.init(chartDom);
      const option = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        legend: {
          data: ['Income', 'Expense']
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: 'Income',
            type: 'bar',
            stack: 'total',
            emphasis: { focus: 'series' },
            itemStyle: { color: '#2ab7a9' },
            data: [3200, 4500, 5200, 4800, 6300, 7100]
          },
          {
            name: 'Expense',
            type: 'bar',
            stack: 'total',
            emphasis: { focus: 'series' },
            itemStyle: { color: '#ff6b6b' },
            data: [2100, 3200, 3800, 3500, 4200, 5000]
          }
        ]
      };
      myChart.setOption(option);
      const resize = () => myChart.resize();
      window.addEventListener('resize', resize);
      return () => {
        window.removeEventListener('resize', resize);
        myChart.dispose();
      };
    }
  }, [activeTab]);

  return (
    <div className="container-fluid min-vh-100 py-4 px-3">
      <div className="container bg-white shadow rounded p-4">
        <div className="mb-4">
          <h3 className="fw-bold">Reports</h3>
          <p className="text-muted">View and download your financial reports</p>
        </div>

        <div className="d-flex border-bottom mb-4">
          {/* <button
            className={`btn border-0 rounded-0 me-2 px-3 py-2 ${activeTab === 'monthly' ? 'fw-semibold' : 'text-muted'}`}
            onClick={() => setActiveTab('monthly')}
            style={activeTab === 'monthly' ? { borderBottom: '3px solid #2ab7a9', color: '#2ab7a9' } : {}}
          >
            Monthly Summary
          </button>
          <button
            className={`btn border-0 rounded-0 px-3 py-2 ${activeTab === 'downloadable' ? 'fw-semibold' : 'text-muted'}`}
            onClick={() => setActiveTab('downloadable')}
            style={activeTab === 'downloadable' ? { borderBottom: '3px solid #2ab7a9', color: '#2ab7a9' } : {}}
          >
            Downloadable Reports
          </button> */}
          <button
            className={`btn border-0 rounded-0 px-3 py-2 ${activeTab === 'children' ? 'fw-semibold' : 'text-muted'}`}
            onClick={() => setActiveTab('children')}
            style={activeTab === 'children' ? { borderBottom: '3px solid #2ab7a9', color: '#2ab7a9' } : {}}
          >
            Children Reports
          </button>
          <button
            className={`btn border-0 rounded-0 px-3 py-2 ${activeTab === 'Staff' ? 'fw-semibold' : 'text-muted'}`}
            onClick={() => setActiveTab('Staff')}
            style={activeTab === 'Staff' ? { borderBottom: '3px solid #2ab7a9', color: '#2ab7a9' } : {}}
          >
            Staff Reports
          </button>
        </div>

        {/* {activeTab === 'monthly' && (
          <>
            <div ref={reportRef}>
              <div className="d-flex flex-wrap justify-content-between align-items-center mb-3">
                <h5>Monthly Summary (Income vs Expense)</h5>
                <div className="d-flex gap-2">
                  <select className="form-select" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)}>
                    {["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map(m => <option key={m}>{m}</option>)}
                  </select>
                  <select className="form-select" value={selectedYear} onChange={e => setSelectedYear(e.target.value)}>
                    {["2023", "2024", "2025"].map(y => <option key={y}>{y}</option>)}
                  </select>
                </div>
              </div>

              <div id="monthly-summary-chart" style={{ width: '100%', height: 400 }} className="mb-4"></div>

              <div className="row g-4 mb-3">
                <div className="col-md-4">
                  <div className="card border-success">
                    <div className="card-body">
                      <h6 className="card-title text-success">Total Income</h6>
                      <h4 className="fw-bold">$7,100.00</h4>
                      <p className="text-muted">+12.5% from last month</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="card border-danger">
                    <div className="card-body">
                      <h6 className="card-title text-danger">Total Expenses</h6>
                      <h4 className="fw-bold">$5,000.00</h4>
                      <p className="text-muted">+19.0% from last month</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="card border-primary">
                    <div className="card-body">
                      <h6 className="card-title text-primary">Net Savings</h6>
                      <h4 className="fw-bold">$2,100.00</h4>
                      <p className="text-muted">+0.5% from last month</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-end">
              <button
                className="btn text-white"
                style={{ backgroundColor: '#2ab7a9' }}
                onClick={handleDownloadReport}
              >
                <i className="fas fa-download me-2"></i>Download report
              </button>
            </div>
          </>
        )} */}
        {activeTab === 'monthly' && (
          <>
            <div ref={reportRef}>
              {/* Monthly Summary Content */}
              <div className="d-flex flex-wrap justify-content-between align-items-center mb-3">
                <h5>Monthly Summary (Income vs Expense)</h5>
                <div className="d-flex gap-2">
                  <select className="form-select" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)}>
                    {["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map(m => <option key={m}>{m}</option>)}
                  </select>
                  <select className="form-select" value={selectedYear} onChange={e => setSelectedYear(e.target.value)}>
                    {["2023", "2024", "2025"].map(y => <option key={y}>{y}</option>)}
                  </select>
                </div>
              </div>

              <div id="monthly-summary-chart" style={{ width: '100%', height: 400 }} className="mb-4"></div>

              {/* Monthly Summary Table */}
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">Month</th>
                    <th scope="col">Total Income</th>
                    <th scope="col">Total Expenses</th>
                    <th scope="col">Net Savings</th>
                    <th scope="col">Change from Last Month</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>September 2023</td>
                    <td>$7,100.00</td>
                    <td>$5,000.00</td>
                    <td>$2,100.00</td>
                    <td>+12.5% Income, +19.0% Expenses</td>
                  </tr>
                  <tr>
                    <td>August 2023</td>
                    <td>$6,300.00</td>
                    <td>$4,200.00</td>
                    <td>$2,100.00</td>
                    <td>+5.0% Income, +10.0% Expenses</td>
                  </tr>
                  <tr>
                    <td>July 2023</td>
                    <td>$6,000.00</td>
                    <td>$3,800.00</td>
                    <td>$2,200.00</td>
                    <td>-2.0% Income, +5.0% Expenses</td>
                  </tr>
                  {/* Add more rows as needed for previous months */}
                </tbody>
              </table>
            </div>

            {/* Download Button */}
            <div className="text-end">
              {/* <button
                className="btn text-white"
                style={{ backgroundColor: '#2ab7a9' }}
                onClick={handleDownloadReport}
              >
                <i className="fas fa-download me-2"></i>Download report
              </button> */}
            </div>
          </>
        )}


        {activeTab === 'downloadable' && (
          <>
            <h5 className="mb-3">Downloadable Reports</h5>
            <div className="row g-3 mb-4">
              <div className="col-sm-4">
                <select className="form-select" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)}>
                  {["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map(m => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div className="col-sm-4">
                <select className="form-select" value={selectedYear} onChange={e => setSelectedYear(e.target.value)}>
                  {["2023", "2024", "2025"].map(y => <option key={y}>{y}</option>)}
                </select>
              </div>
              <div className="col-sm-4">
                <select className="form-select" value={selectedFormat} onChange={e => setSelectedFormat(e.target.value)}>
                  {["PDF", "Excel", "CSV"].map(f => <option key={f}>{f}</option>)}
                </select>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-bordered">
                <thead className="table-light">
                  <tr>
                    <th>Report Name</th>
                    <th>Last Generated</th>
                    <th className="text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {reportList.map((r, idx) => (
                    <tr key={idx}>
                      <td><i className={`fas fa-${r.icon} text-info me-2`}></i>{r.name}</td>
                      <td>{r.date}</td>
                      <td className="text-end">
                        <button
                          className="btn btn-sm text-white"
                          style={{ backgroundColor: '#2ab7a9' }}
                          onClick={() => handleTableReportDownload(r)}
                        >
                          <i className="fas fa-download me-1"></i>Download
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="alert alert-info mt-4 d-flex align-items-start">
              <i className="fas fa-info-circle me-2 fs-4"></i>
              <div>
                <strong>Need a custom report?</strong><br />
                Contact support to generate reports based on date ranges, categories, or accounts.
              </div>
            </div>
          </>
        )}

        {activeTab === 'children' && (
          <div className="mt-5" ref={summaryRef}>
            <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
              <h3 className="fw-semibold" style={{ color: '#2ab7a9' }}>Monthly Enrollment Summary</h3>
              <div className="d-flex gap-2">
                {/* <button className="btn text-white" style={{ backgroundColor: '#2ab7a9' }} onClick={handleDownloadSummaryPDF}>
                  <FaFile size={18} className="me-1" /> Report
                </button> */}
              </div>
            </div>
            <div className="mt-3">
              <div className="card shadow-sm border-0">
                <div className="card-body">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData} margin={{ top: 20, right: 30, left: 40, bottom: 40 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" stroke="#555">
                        <Label value="Month of Enrollment" offset={-30} position="insideBottom" />
                      </XAxis>
                      <YAxis allowDecimals={false} stroke="#555">
                        <Label
                          value="Number of Enrollments"
                          angle={-90}
                          position="insideLeft"
                          offset={-10}
                          style={{ textAnchor: 'middle' }}
                        />
                      </YAxis>
                      <Tooltip />
                      <Bar dataKey="count" fill="#2ab7a9" radius={[5, 5, 0, 0]} barSize={40} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'Staff' && (
          <div className="mt-5">
            <div className="card shadow-sm border-0">
              <div className="card-header bg-white d-flex justify-content-between align-items-center mb-2">
                <h5 className="mb-0 fw-semibold" style={{ color: "#2ab7a9" }}>Staff Approval Summary</h5>
                {/* <button
                  className="btn btn-sm text-white"
                  style={{ backgroundColor: "#2ab7a9" }}
                  onClick={handleDownloadPDF}
                >
                  <FaFileAlt className="me-1" /> Download Report
                </button> */}
              </div>
              <div className="card-body mt-3">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={staffChartData} margin={{ top: 20, right: 30, left: 40, bottom: 40 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="status" stroke="#555">
                      <Label value="Approval Status" offset={-10} position="insideBottom" />
                    </XAxis>
                    <YAxis allowDecimals={false} stroke="#555">
                      <Label
                        value="Number of Staff"
                        angle={-90}
                        position="insideLeft"
                        offset={-10}
                        style={{ textAnchor: 'middle' }}
                      />
                    </YAxis>
                    <Tooltip />
                    <Bar dataKey="count" fill="#2ab7a9" radius={[5, 5, 0, 0]} barSize={40} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

        )}

      </div>
    </div>
  );
};

export default AccountReports;
