import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { addUser, getUsers, updateUser, deleteUser } from "../../../redux/slices/userSlice";
import { showToastPromise } from "../../../utils/showToastPromise";
import { useConfirmDelete } from "../../../hooks/useCustomDelete";

const UserManagementTab = ({ reusableColor, handleEditUser, handleViewUser, setShowAddUserModal, showAddUserModal, setShowEditModal, setShowViewModal }) => {
  const dispatch = useDispatch();

  const { user, loading } = useSelector((state) => state.user);
  const [userform, setUserform] = useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    role_id: 4,
    status: "active",
  });
  const [showEditMode, setShowEditMode] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  const handleUserInputChange = (e) => {
    const { name, value } = e.target;
    setUserform((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    const requiredFields = [
      { key: "first_name", label: "First Name" },
      { key: "last_name", label: "Last Name" },
      { key: "email", label: "Email" },
      { key: "password", label: "Password" },
      { key: "role_id", label: "Role" },
    ];

    for (let field of requiredFields) {
      if (!userform[field.key]?.trim()) {
        toast.error(`${field.label} is required`);
        return;
      }
    }

    if (!showEditMode) {
      const exists = user.some((u) => u.email?.toLowerCase() === userform.email.trim().toLowerCase());
      if (exists) {
        toast.error("Email already exists");
        return;
      }
    }

    const payload = {
      ...userform,
      user_id: userform.user_id,
    };

    const action = showEditMode ? updateUser(payload) : addUser(payload);
    const promise = dispatch(action).unwrap();

    showToastPromise(promise, {
      loading: showEditMode ? "Updating user..." : "Adding user...",
      success: (res) => res.message || (showEditMode ? "User updated!" : "User added!"),
      error: (err) => err.message || "Something went wrong",
    });

    try {
      await promise;
      setUserform({ first_name: "", last_name: "", email: "", password: "", role_id: 4, status: "active" });
      setShowAddUserModal(false);
      setShowEditMode(false);
      dispatch(getUsers());
    } catch (err) {
      console.error("Error:", err);
    }
  };

  const { confirmAndDelete } = useConfirmDelete();

  const handleUserDelete = (id) => {
    confirmAndDelete({
      id,
      action: deleteUser,
      entity: "User",
      onSuccess: () => dispatch(getUsers()),
    });
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="h5 fw-semibold text-dark">User Management</h2>
        <button
          className="btn text-white d-flex align-items-center"
          style={{ backgroundColor: reusableColor.customTextColor }}
          onClick={() => setShowAddUserModal(true)}
        >
          <i className="fas fa-plus me-2"></i> Add User
        </button>
      </div>

      {loading ? (
        <div className='text-center'>Loading ..</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover">
            <thead className="table-light">
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {user && user.length > 0 ? (
                user.map((u) => (
                  <tr key={u.user_id}>
                    <td className="fw-medium">{u.first_name} {u.last_name}</td>
                    <td>{u.email}</td>
                    <td><span className="badge bg-primary-subtle text-primary">{u.name}</span></td>
                    <td><span className={`badge ${u.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'}`}>{u.status}</span></td>
                    <td>
                      <div className="d-flex gap-2">
                        {/* <button className="btn btn-sm text-success p-0" title="Edit" onClick={() => handleEditUser(u)}>
                          <i className="fas fa-edit"></i>
                        </button> */}
                        <button className="btn btn-sm text-info p-0" title="View" onClick={() => handleViewUser(u)}>
                          <i className="fas fa-eye"></i>
                        </button>
                        <button className="btn btn-sm text-danger p-0" onClick={() => handleUserDelete(u.user_id)}>
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5">No users found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default UserManagementTab;
