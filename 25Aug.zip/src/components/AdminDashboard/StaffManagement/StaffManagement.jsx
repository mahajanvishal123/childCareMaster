import React, { useState, useRef, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Modal, Button, Pagination } from "react-bootstrap";
import html2pdf from 'html2pdf.js';
import {
  FaPlus,
  FaInfoCircle,
  FaFileAlt,
  FaEye,
  FaEdit,
  FaTrash,
} from "react-icons/fa";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Label
} from 'recharts';

import AddStaff from './AddStaff';
import CourseTable from "./CourseTable";
import axios from "axios";
import { BASE_URL } from "../../../utils/config";
import { useConfirmDelete } from '../../../hooks/useCustomDelete';
import Swal from "sweetalert2";

const StaffManagement = () => {
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // Modal states for Add Staff and Credentials
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [userData, setUserData] = useState(null);

  const [filteredStaffList, setFilteredStaffList] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  const itemsPerPage = 5;
  const tableRef = useRef();
  const { confirmAndDelete } = useConfirmDelete();

  // User credentials form state
  const [userform, setUserform] = useState({ email: '', password: '' });

  // Staff list and loading
  const [staffList, setStaffList] = useState([]);

  console.log("stafflist", staffList);
  const [loading, setLoading] = useState(true);

  // Fetch staff list
  const fetchStaffList = () => {
    setLoading(true);
    axios.get(`${BASE_URL}/teachers`)
      .then((res) => {
        console.log("res.data", res.data);
        if (res.data) {
          const mapped = res.data.map((item) => ({
            id: item.user_id,
            initials: `${ item.first_name ? item.first_name[0] || '' : ''}${ item.last_name ? item.last_name[0] || '' : ''}`.toUpperCase()  || '',
            name: `${item?.first_name} ${item?.last_name}`,
            email: item?.email,
            dob: new Date(item?.dob).toLocaleDateString(),
            courses: ["CPR", "First Aid"],
            qualifications: item?.notes || "N/A",
            approval: item?.cbc_status,
            immunizations: item?.status,
            documents: [
              { url: item?.photo, name: "Photo" },
              { url: item?.medical_form, name: "Medical Form" },
              { url: item?.credentials, name: "Credentials" },
              { url: item?.cbc_worksheet, name: "CBC Worksheet" },
              { url: item?.auth_affirmation_form, name: "Auth Affirmation" },
              { url: item?.mandated_reporter_cert, name: "Mandated Reporter" },
              { url: item?.preventing_sids_cert, name: "SIDS Cert" },
            ]
          }));
          setStaffList(mapped);
          setFilteredStaffList(mapped);
        }
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchStaffList();
  }, []);

  useEffect(() => {
    const filtered = staffList.filter((staff) => {
      const searchTarget = `${staff.name} ${staff.qualifications}`.toLowerCase();
      return searchTarget.includes(searchQuery.toLowerCase());
    });
    setFilteredStaffList(filtered);
  }, [searchQuery, staffList]);

  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const totalPages = Math.ceil(staffList.length / itemsPerPage);

  // Download PDF
  const handleDownloadPDF = () => {
    const element = tableRef.current;
    const opt = {
      margin: 0.3,
      filename: 'staff-report.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
    };
    html2pdf().set(opt).from(element).save();
  };

  // Chart data
  const chartData = (() => {
    const summary = {};
    staffList.forEach(staff => {
      const status = (staff.approval || '').toLowerCase();
      summary[status] = (summary[status] || 0) + 1;
    });
    return Object.keys(summary).map(status => ({
      status: status,
      count: summary[status]
    }));
  })();

  // Modal handlers
  const handleViewOpen = (staff) => {
    setSelectedStaff(staff);
    setShowViewModal(true);
  };
  const handleViewClose = () => {
    setSelectedStaff(null);
    setShowViewModal(false);
  };
  const handleEditOpen = (staff) => {
    setSelectedStaff(staff);
    setShowEditModal(true);
  };
  const handleEditClose = () => {
    setSelectedStaff(null);
    setShowEditModal(false);
  };
  const handleSaveChanges = () => {
    // Implement save logic here
    setShowEditModal(false);
  };

  // Add Staff Modal flow
  const handleAddNewStaff = () => {
    setShowStaffModal(true);
    setUserData(null);
  };
  const handleStaffModalClose = () => {
    setShowStaffModal(false);
    setUserData(null);
  };
  const handleOpenUserModal = () => setShowUserModal(true);
  const handleUserModalClose = () => setShowUserModal(false);

  // User credentials form handlers
  const handleUserInputChange = (e) => {
    const { name, value } = e.target;
    setUserform((prev) => ({ ...prev, [name]: value }));
  };
  const handleAddUser = (e) => {
    e.preventDefault();
    setUserData(userform);
    setShowUserModal(false);
    setUserform({ email: '', password: '' });
  };

  // After staff added
  const handleStaffAdded = () => {
    fetchStaffList();
    setShowStaffModal(false);
    setUserData(null);
  };

  // Delete staff
  const HandleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    });

    if (result.isConfirmed) {
      try {
        await axios.delete(`${BASE_URL}/teachers/${id}`);
        await Swal.fire("Deleted!", "Staff has been deleted.", "success");
        fetchStaffList && fetchStaffList();
      } catch (err) {
        Swal.fire("Error", "Failed to delete staff.", "error");
      }
    }
  };

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: "#fff" }} ref={tableRef}>
      <div className="row mb-3 align-items-center">
        <div className="col-md-6 col-12">
          <h3 className="fw-semibold mb-2 mb-md-0" style={{ color: "#2ab7a9" }}>
            Staff List
          </h3>
        </div>
        <div className="col-md-6 col-12 text-md-end">
          <div className="d-flex flex-wrap justify-content-md-end gap-2">
            <button
              className="btn btn-sm text-white"
              style={{ backgroundColor: "#2ab7a9" }}
              onClick={handleDownloadPDF}
            >
              <FaFileAlt className="me-1" /> Download Report
            </button>
            <button
              className="btn btn-sm text-white"
              style={{ backgroundColor: "#2ab7a9" }}
              onClick={handleAddNewStaff}
            >
              <FaPlus size={14} className="me-1" /> Add New Staff
            </button>
          </div>
        </div>
      </div>

      <input
        type="text"
        className="form-control mb-3"
        placeholder="Search by Staff Name or Qualification"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      <div className="table-responsive bg-white p-2 rounded shadow-sm ">
        <table className="table table-bordered align-middle mb-0">
          <thead className="table-light">
            <tr>
              <th>Staff Name</th>
              <th className="d-none d-sm-table-cell">Date of Birth</th>
              <th className="d-none d-md-table-cell">Required Courses</th>
              <th className="d-none d-lg-table-cell">Qualifications</th>
              <th>Approval Status</th>
              <th>Immunizations</th>
              <th>Documents</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan="9" className="text-center text-muted">Loading...</td>
              </tr>
            )}
            {!loading && filteredStaffList.map((staff, idx) => (
              <tr key={idx}>
                <td>
                  <div className="d-flex align-items-center">
                    <div className="rounded-circle text-white d-flex justify-content-center align-items-center me-2" style={{ width: "35px", height: "35px", backgroundColor: "#2ab7a9" }}>{staff.initials}</div>
                    <div>
                      <strong>{staff.name}</strong>
                      <div className="text-muted" style={{ fontSize: "0.875rem" }}>{staff.email}</div>
                    </div>
                  </div>
                </td>
                <td className="d-none d-sm-table-cell">{staff.dob}</td>
                <td className="d-none d-md-table-cell">
                  {staff.courses.map((course, i) => (
                    <span key={i} className={`badge bg-${getCourseColor(course)} me-1`}>{course}</span>
                  ))}
                </td>
                <td className="d-none d-lg-table-cell">{staff.qualifications}</td>
                <td><span className={`badge bg-${getApprovalColor(staff.approval)}`}>{staff.approval}</span></td>
                <td>
                  <i className={`bi ${staff.immunizations === "Completed" ? "bi-check-circle-fill text-success" : "bi-exclamation-circle-fill text-warning"} me-1`}></i>
                  {staff.immunizations}
                </td>
                <td className="text-center">
                  {staff.documents?.map((doc, i) => (
                    <a
                      key={i}
                      href={doc.url}
                      download
                      title={doc.name}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="me-1"
                    >
                      <FaFileAlt size={20} color="#2ab7a9" />
                    </a>
                  ))}
                </td>
                <td className="text-center">
                  <div className="d-flex flex-wrap justify-content-center gap-2">
                    <button className="btn btn-sm btn-outline-secondary" title="View" onClick={() => handleViewOpen(staff)}><FaEye size={16} /></button>
                    {/* <button className="btn btn-sm btn-outline-primary" title="Edit" onClick={() => handleEditOpen(staff)}><FaEdit size={16} /></button> */}
                    <button className="btn btn-sm btn-outline-danger" title="Delete" onClick={() => HandleDelete(staff.id)}><FaTrash size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
            {!loading && staffList.length === 0 && (
              <tr>
                <td colSpan="9" className="text-center text-muted">No records found.</td>
              </tr>
            )}
          </tbody>
        </table>

        {/* Add Staff Modal */}
        <Modal show={showStaffModal} onHide={handleStaffModalClose} size="xl" centered>
          <Modal.Header closeButton style={{ backgroundColor: '#2ab7a9', color: 'white' }}>
            <Modal.Title>Add New Staff</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {/* Button to open credentials modal */}
            <div className="mb-3 text-end">
              <Button   style={{ backgroundColor: "#2ab7a9" }}
             className="btn btn-sm text-white border-0"
                onClick={handleOpenUserModal}
              >
                Add Staff User Credentials
              </Button>
            </div>
            <AddStaff userData={userData} handleModalClose={handleStaffModalClose} onStaffAdded={handleStaffAdded} />
          </Modal.Body>
        </Modal>

        {/* Staff User Credentials Modal */}
        <Modal show={showUserModal} onHide={handleUserModalClose} className='modal-dialog-centered' centered>
          <Modal.Header closeButton style={{ backgroundColor: '#2ab7a9', color: 'white' }}>
            <Modal.Title>Staff User Credentials</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={handleAddUser}>
              <div className="mb-3">
                <label className="form-label">Email</label>
                <input type="email" className="form-control" name="email" value={userform.email} onChange={handleUserInputChange} required />
              </div>
              <div className="mb-3">
                <label className="form-label">Password</label>
                <input type="password" className="form-control" name="password" value={userform.password} onChange={handleUserInputChange} required />
              </div>
              <div className="d-flex justify-content-end gap-2">
                <Button variant="secondary" onClick={handleUserModalClose}>Cancel</Button>
                <Button style={{ backgroundColor: '#2ab7a9', borderColor: '#2ab7a9' }} type="submit">
                  Save Credentials
                </Button>
              </div>
            </form>
          </Modal.Body>
        </Modal>
      </div>

      <Pagination className="justify-content-end mt-3">
        <Pagination.Prev onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))} disabled={currentPage === 1} />
        {[...Array(totalPages)].map((_, i) => (
          <Pagination.Item key={i} active={i + 1 === currentPage} onClick={() => setCurrentPage(i + 1)}>
            {i + 1}
          </Pagination.Item>
        ))}
        <Pagination.Next onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))} disabled={currentPage === totalPages} />
      </Pagination>

      {/* View Modal */}
      <Modal show={showViewModal} onHide={handleViewClose} centered dialogClassName="modal-lg">
        <Modal.Header closeButton style={{ backgroundColor: "#2ab7a9", color: "white" }}>
          <Modal.Title>Staff Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedStaff && (
            <div className="p-2">
              {/* Personal Information */}
              <div className="border rounded mb-3 p-3 shadow-sm">
                <h5 className="mb-3"><FaInfoCircle className="me-2" />Personal Information</h5>
                <div className="row">
                  <div className="col-md-6"><strong>Full Name:</strong> {selectedStaff.name}</div>
                  <div className="col-md-6"><strong>Date of Birth:</strong> {selectedStaff.dob}</div>
                  <div className="col-md-6"><strong>Email:</strong> {selectedStaff.email}</div>
                  <div className="col-md-6"><strong>Approval Status:</strong> {selectedStaff.approval}</div>
                </div>
              </div>
              {/* Parent Details (dummy info) */}
              <div className="border rounded mb-3 p-3 shadow-sm">
                <h5 className="mb-3"><FaInfoCircle className="me-2" />Parent Details</h5>
                <div className="row">
                  <div className="col-md-6"><strong>Father's Name:</strong> Mr. John Blackwell</div>
                  <div className="col-md-6"><strong>Mother's Name:</strong> Mrs. Emily Blackwell</div>
                  <div className="col-md-6"><strong>Father's Phone:</strong> (555) 999-1234</div>
                  <div className="col-md-6"><strong>Mother's Phone:</strong> (555) 888-5678</div>
                </div>
              </div>
              {/* Contact & Address */}
              <div className="border rounded mb-3 p-3 shadow-sm">
                <h5 className="mb-3"><FaInfoCircle className="me-2" />Contact & Address</h5>
                <div className="row">
                  <div className="col-md-12"><strong>Address:</strong> 123 Main Street, City, State, 000000</div>
                  <div className="col-md-6"><strong>Phone Number:</strong> (555) 123-4567</div>
                </div>
              </div>
              {/* Documents & Qualifications */}
              <div className="border rounded mb-2 p-3 shadow-sm">
                <h5 className="mb-3"><FaFileAlt className="me-2" />Documents & Qualifications</h5>
                <div className="row">
                  <div className="col-md-6"><strong>Courses:</strong> {selectedStaff.courses.join(', ')}</div>
                  <div className="col-md-6"><strong>Immunization:</strong> {selectedStaff.immunizations}</div>
                  <div className="col-md-12"><strong>Qualifications:</strong> {selectedStaff.qualifications}</div>
                </div>
              </div>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="light" onClick={handleViewClose}>Close</Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Modal */}
      <Modal show={showEditModal} onHide={handleEditClose} centered dialogClassName="modal-lg">
        <Modal.Header closeButton style={{ backgroundColor: "#2ab7a9", color: "white" }}>
          <Modal.Title>Update Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedStaff && (
            <div className="p-2">
              {/* Personal Information */}
              <div className="border rounded mb-3 p-3 shadow-sm">
                <h5 className="mb-3">📘 Personal Information</h5>
                <div className="row">
                  <div className="col-md-3 d-flex align-items-center">
                    <img src="https://via.placeholder.com/80" alt="Profile" className="img-fluid rounded-circle" />
                  </div>
                  <div className="col-md-9">
                    <div className="mb-2"><strong>Full Name:</strong> <input type="text" className="form-control" defaultValue={selectedStaff.name} /></div>
                    <div className="row mb-2">
                      <div className="col-md-6">
                        <strong>Nickname (English):</strong> <input type="text" className="form-control" defaultValue="Davy" />
                      </div>
                      <div className="col-md-6">
                        <strong>Nickname (Hebrew):</strong> <input type="text" className="form-control" defaultValue="דודי" />
                      </div>
                    </div>
                    <div className="row mb-2">
                      <div className="col-md-6">
                        <strong>Date of Birth (English):</strong> <input type="date" className="form-control" defaultValue="2018-03-14" />
                      </div>
                      <div className="col-md-6">
                        <strong>Date of Birth (Hebrew):</strong> <input type="text" className="form-control" defaultValue="27 Adar 5778" />
                      </div>
                    </div>
                    <div className="mb-2">
                      <strong>Number in Family:</strong> <input type="text" className="form-control" defaultValue="2 of 4" />
                    </div>
                    <div className="mb-2">
                      <strong>Assigned Classroom:</strong>
                      <select className="form-select">
                        <option>Blue Room</option>
                        <option>Red Room</option>
                        <option>Yellow Room</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              {/* Parent Details */}
              <div className="border rounded mb-3 p-3 shadow-sm">
                <h5 className="mb-3">👨‍👩‍👦 Parent Details</h5>
                <div className="row">
                  <div className="col-md-6">
                    <strong>Mother's Name:</strong> <input className="form-control" defaultValue="Sarah Cohen" />
                  </div>
                  <div className="col-md-6">
                    <strong>Mother's Phone:</strong> <input className="form-control" defaultValue="(555) 123-4567" />
                  </div>
                  <div className="col-md-6">
                    <strong>Father's Name:</strong> <input className="form-control" defaultValue="Jacob Cohen" />
                  </div>
                  <div className="col-md-6">
                    <strong>Father's Phone:</strong> <input className="form-control" defaultValue="(555) 987-6543" />
                  </div>
                </div>
              </div>
              {/* Contact & Address */}
              <div className="border rounded mb-3 p-3 shadow-sm">
                <h5 className="mb-3">📞 Contact & Address</h5>
                <div className="mb-2">
                  <strong>Address:</strong> <input className="form-control" defaultValue="123 Main Street, City, State" />
                </div>
                <div className="mb-2">
                  <strong>Phone Number:</strong> <input className="form-control" defaultValue="(555) 123-4567" />
                </div>
              </div>
              {/* Documents */}
              <div className="border rounded mb-2 p-3 shadow-sm">
                <h5 className="mb-3">📄 Documents & Qualifications</h5>
                <div className="mb-2">
                  <strong>Courses:</strong> <input className="form-control" defaultValue={selectedStaff.courses.join(', ')} />
                </div>
                <div className="mb-2">
                  <strong>Qualifications:</strong> <input className="form-control" defaultValue={selectedStaff.qualifications} />
                </div>
                <div className="mb-2">
                  <strong>Immunizations:</strong> <input className="form-control" defaultValue={selectedStaff.immunizations} />
                </div>
              </div>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleEditClose}>Cancel</Button>
          <Button
            style={{ backgroundColor: "#2ab7a9", borderColor: "#2ab7a9" }}
            onClick={handleSaveChanges}
          >
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      <div className="mt-5">
        <div className="card shadow-sm border-0">
          <div className="card-header bg-white d-flex justify-content-between align-items-center mb-2">
            <h5 className="mb-0 fw-semibold" style={{ color: "#2ab7a9" }}>Staff Approval Summary</h5>
            <button
              className="btn btn-sm text-white"
              style={{ backgroundColor: "#2ab7a9" }}
              onClick={handleDownloadPDF}
            >
              <FaFileAlt className="me-1" /> Download Report
            </button>
          </div>
          <div className="card-body mt-3">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 40, bottom: 40 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="status" stroke="#555">
                  <Label value="Approval Status" offset={-10} position="insideBottom" />
                </XAxis>
                <YAxis allowDecimals={false} stroke="#555">
                  <Label
                    value="Number of Staffs"
                    angle={-90}
                    position="insideLeft"
                    offset={-10}
                    style={{ textAnchor: 'middle' }}
                  />
                </YAxis>
                <Tooltip />
                <Bar dataKey="count" fill="#2ab7a9" radius={[5, 5, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Course Table */}
      <CourseTable />
    </div>
  );
};

const getCourseColor = (course) => {
  switch (course) {
    case "First Aid": return "info";
    case "Child Development": return "secondary";
    case "Safety": return "success";
    case "CPR": return "danger";
    default: return "primary";
  }
};

const getApprovalColor = (status) => {
  switch (status) {
    case "Approved": return "success";
    case "Provisionally Approved": return "warning";
    case "Not Approved": return "danger";
    default: return "secondary";
  }
};

export default StaffManagement;