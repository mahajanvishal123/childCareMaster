import React, { useEffect, useState } from "react";
import axios from "axios";
import html2pdf from "html2pdf.js";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { Modal, Button, Form } from "react-bootstrap";
import { BASE_URL } from "../../../utils/config";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
const Outstandingrequirement = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [dateRange, setDateRange] = useState({
    start: "2025-06-01",
    end: "2025-06-23",
  });
  const [status, setStatus] = useState("All");
  const [department, setDepartment] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedChild, setSelectedChild] = useState(null);
  const [showChildViewModal, setShowChildViewModal] = useState(false);
  const [showChildEditModal, setShowChildEditModal] = useState(false);
  const [selectedMaintenance, setSelectedMaintenance] = useState(null);
  const [showLocationViewModal, setShowLocationViewModal] = useState(false);
  const [showLocationEditModal, setShowLocationEditModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState(null);

  // Data and pagination state
  const [teachers, setTeachers] = useState([]);
  const [teacherTotal, setTeacherTotal] = useState(0);
  const [teacherTotalPages, setTeacherTotalPages] = useState(1);
  const [teacherPage, setTeacherPage] = useState(1);

  const [children, setChildren] = useState([]);
  const [childTotal, setChildTotal] = useState(0);
  const [childTotalPages, setChildTotalPages] = useState(1);
  const [childPage, setChildPage] = useState(1);

  const [maintenance, setMaintenance] = useState([]);
  const [maintenanceTotal, setMaintenanceTotal] = useState(0);
  const [maintenanceTotalPages, setMaintenanceTotalPages] = useState(1);
  const [maintenancePage, setMaintenancePage] = useState(1);

  const [loading, setLoading] = useState(true);

  // Fetch all data in one call, using all page states
  // useEffect(() => {
  //   setLoading(true);
  //   axios.get(`${BASE_URL}/outstanding-requirements/filter`, {
  //     params: {
  //       page: teacherPage,
  //       teacherPage,
  //       childPage,
  //       maintenancePage,
  //       // Add filters here if needed
  //     },
  //   })
  //     .then(res => {
  //       if (res.data.success) {
  //         // Teachers
  //         setTeachers(res.data.teachers.data || []);
  //         setTeacherTotal(res.data.teachers.total || 0);
  //         setTeacherTotalPages(res.data.teachers.totalPages || 1);
  //         // Children
  //         setChildren(res.data.children.data || []);
  //         setChildTotal(res.data.children.total || 0);
  //         setChildTotalPages(res.data.children.totalPages || 1);
  //         // Maintenance
  //         setMaintenance(res.data.maintenanceRequirements.data || []);
  //         setMaintenanceTotal(res.data.maintenanceRequirements.total || 0);
  //         setMaintenanceTotalPages(res.data.maintenanceRequirements.totalPages || 1);
  //       }
  //     })
  //     .catch(err => {
  //       console.error(err);
  //     })
  //     .finally(() => setLoading(false));
  // }, [teacherPage, childPage, maintenancePage]);


  useEffect(() => {
    setLoading(true);
    axios.get(`${BASE_URL}/outstanding-requirements/filter`, {
      params: {
        teacherPage,
        childPage,
        maintenancePage,
        // Add filters if backend supports them
        startDate: dateRange.start,
        endDate: dateRange.end,
        status: status !== "All" ? status : undefined,
        search: searchTerm || undefined
      }
    })
    .then(res => {
      if (res.data.success) {
        // Teachers
        setTeachers(res.data.teachers.data || []);
        setTeacherTotal(res.data.teachers.total || 0);
        setTeacherTotalPages(res.data.teachers.totalPages || 1);
        
        // Children
        setChildren(res.data.children.data || []);
        setChildTotal(res.data.children.total || 0);
        setChildTotalPages(res.data.children.totalPages || 1);
        
        // Maintenance
        setMaintenance(res.data.maintenanceRequirements.data || []);
        setMaintenanceTotal(res.data.maintenanceRequirements.total || 0);
        setMaintenanceTotalPages(res.data.maintenanceRequirements.totalPages || 1);
      }
    })
    .catch(err => console.error("Fetch error:", err))
    .finally(() => setLoading(false));
  }, [teacherPage, childPage, maintenancePage, dateRange, status, searchTerm]);


    const isDateInRange = (dateString, start, end) => {
    if (!dateString) return true;
    const date = new Date(dateString);
    const startDate = new Date(start);
    const endDate = new Date(end);
    
    // Normalize to local date
    const checkDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const normStart = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
    const normEnd = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());
    
    return checkDate >= normStart && checkDate <= normEnd;
  };

  // Filter data
  const filteredTeachers = teachers.filter(item => {
    const fullName = `${item.first_name || ''} ${item.last_name || ''}`.trim();
    return (
      fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.user_id || "").includes(searchTerm)
    ) && (
      status === "All" || item.status === status
    ) && (
      isDateInRange(item.due_date, dateRange.start, dateRange.end)
    );
  });

  const filteredChildren = children.map(child => ({
    ...child,
    full_name: `${child.first_name || ''} ${child.last_name || ''}`.trim() || "Incomplete Profile"
  })).filter(child => {
    return (
      child.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (child.child_id || "").includes(searchTerm)
    ) && (
      status === "All" || child.status === status
    ) && (
      isDateInRange(child.enrollment_date, dateRange.start, dateRange.end)
    );
  });

  const filteredMaintenance = maintenance.filter(item => {
    return (
      (item.location || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.request_title || "").toLowerCase().includes(searchTerm.toLowerCase())
    ) && (
      status === "All" || item.status === status
    ) && (
      isDateInRange(item.date_reported, dateRange.start, dateRange.end)
    );
  });

  // PDF Export Function
  const handleExportPDF = () => {
    const element = document.getElementById("reportContent");
    const opt = {
      margin: 0.5,
      filename: "report.pdf",
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "in", format: "letter", orientation: "portrait" },
    };
    html2pdf().set(opt).from(element).save();
  };

  // Excel Export Function
  const handleExportExcel = () => {
    const table = document.querySelector("#reportContent table");
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.table_to_sheet(table);
    XLSX.utils.book_append_sheet(wb, ws, "Report");
    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    saveAs(new Blob([wbout], { type: "application/octet-stream" }), "report.xlsx");
  };

  // Pagination controls for each section
const renderPagination = (page, setPage, totalPages, total, label) => (
    total > 0 && (
      <div className="d-flex justify-content-between align-items-center my-2">
        <div>
          <span>
            Showing <span className="fw-medium">
              {Math.min(total, (page - 1) * 10 + 1)}
            </span> to <span className="fw-medium">
              {Math.min(page * 10, total)}
            </span> of <span className="fw-medium">{total}</span> {label}
          </span>
        </div>
        {totalPages > 1 && (
          <nav aria-label="Page navigation">
            <ul className="pagination pagination-sm mb-0">
              <li className={`page-item${page === 1 ? " disabled" : ""}`}>
                <button 
                  className="page-link" 
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
              </li>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const pageNum = i + 1;
                return (
                  <li 
                    key={pageNum} 
                    className={`page-item${page === pageNum ? " active" : ""}`}
                  >
                    <button 
                      className="page-link" 
                      onClick={() => setPage(pageNum)}
                    >
                      {pageNum}
                    </button>
                  </li>
                );
              })}
              {totalPages > 5 && (
                <li className="page-item disabled">
                  <span className="page-link">...</span>
                </li>
              )}
              <li className={`page-item${page === totalPages ? " disabled" : ""}`}>
                <button 
                  className="page-link" 
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </li>
            </ul>
          </nav>
        )}
      </div>
    )
  );
 return (
    <div className="bg-light min-vh-100" id="reportContent">
      <div className="container-fluid px-4 py-4">
        {/* Header and Export Buttons */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h1 className="h2 text-dark mb-0">Outstanding Requirements</h1>
          <div className="d-flex gap-2">
            <button className="btn btn-outline-danger btn-sm" onClick={handleExportPDF}>
              <i className="fas fa-file-pdf me-2"></i> Export PDF
            </button>
            <button className="btn btn-outline-success btn-sm" onClick={handleExportExcel}>
              <i className="fas fa-file-excel me-2"></i> Export Excel
            </button>
          </div>
        </div>

        {/* Filters Section */}
        <div className="card mb-4">
          <div className="card-body">
            <div className="row g-3 align-items-end">
              {/* Date Range Picker */}
              <div className="col-12 col-md-6 col-lg-3">
                <label className="form-label">Date Range</label>
                <div className="d-flex flex-column flex-md-row align-items-start align-items-md-center gap-2">
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="Start Date"
                      format="DD/MM/YYYY"
                      value={dayjs(dateRange.start)}
                      onChange={(newValue) => 
                        setDateRange({
                          ...dateRange,
                          start: newValue ? newValue.format("YYYY-MM-DD") : ""
                        })
                      }
                      slotProps={{
                        textField: {
                          size: 'small',
                          fullWidth: true
                        }
                      }}
                    />
                  </LocalizationProvider>

                  <span className="text-muted d-none d-md-block">to</span>

                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="End Date"
                      format="DD/MM/YYYY"
                      value={dayjs(dateRange.end)}
                      onChange={(newValue) => 
                        setDateRange({
                          ...dateRange,
                          end: newValue ? newValue.format("YYYY-MM-DD") : ""
                        })
                      }
                      slotProps={{
                        textField: {
                          size: 'small',
                          fullWidth: true
                        }
                      }}
                    />
                  </LocalizationProvider>
                </div>
              </div>

              {/* Status Filter */}
              <div className="col-12 col-md-6 col-lg-2">
                <label className="form-label">Status</label>
                <select
                  className="form-select"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  {["All", "Overdue", "Pending", "In Progress", "Scheduled"].map(item => (
                    <option key={item} value={item}>{item}</option>
                  ))}
                </select>
              </div>

              {/* Type Filter */}
              <div className="col-12 col-md-6 col-lg-2">
                <label className="form-label">Type</label>
                <select
                  className="form-select"
                  value={activeTab}
                  onChange={(e) => setActiveTab(e.target.value)}
                >
                  <option value="all">All Types</option>
                  <option value="Staff">Staff Training</option>
                  <option value="immunization">Children Immunization</option>
                  <option value="maintenance">Location Maintenance</option>
                </select>
              </div>

              {/* Search */}
              <div className="col-12 col-md-6 col-lg-5">
                <label className="form-label">Search</label>
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="fas fa-search"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by name, ID, or location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  {searchTerm && (
                    <button
                      className="btn btn-outline-secondary"
                      type="button"
                      onClick={() => setSearchTerm("")}
                    >
                      <i className="fas fa-times"></i>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="mt-2">Loading requirements...</p>
          </div>
        )}

        {/* Combined Results Section */}
        {!loading && (
          <div className="card">
            {/* Staff Training Section */}
            {(activeTab === "all" || activeTab === "Staff") && (
              <div className="mb-4">
                <div className="card-header bg-primary bg-opacity-10">
                  <h2 className="h5 mb-0">Staff Requirements</h2>
                </div>
                
                {filteredTeachers.length > 0 ? (
                  <>
                    <div className="table-responsive">
                      <table className="table table-hover mb-0">
                        {/* Table header */}
                        <thead className="table-light">
                          <tr>
                            <th scope="col">Staff Name</th>
                            {/* <th scope="col">Department</th> */}
                            <th scope="col">Last Completed</th>
                            <th scope="col">Due Date</th>
                            <th scope="col">Status</th>
                            <th scope="col">Missing Fields</th>
                            <th scope="col">Actions</th>
                          </tr>
                        </thead>
                        
                        {/* Table body */}
                        <tbody>
                          {filteredTeachers.map((item) => (
                            <tr key={item.user_id}>
                              <td>
                                <div className="d-flex align-items-center">
                                  <div className="avatar-placeholder me-3">
                                    {((item.first_name?.[0] || '') + (item.last_name?.[0] || '')).toUpperCase() || 'NA'}
                                  </div>
                                  <div>
                                    <div className="fw-medium">
                                      {item.first_name || "N/A"} {item.last_name || "N/A"}
                                    </div>
                                    <div className="text-muted small">ID: {item.user_id}</div>
                                    {/* <div className="text-muted small">{item.email}</div> */}
                                  </div>
                                </div>
                              </td>
                              {/* <td>{item.department || "N/A"}</td> */}
                              <td>
                                {item.last_completed 
                                  ? new Date(item.last_completed).toLocaleDateString() 
                                  : "Never"}
                              </td>
                              <td>
                                {item.due_date 
                                  ? new Date(item.due_date).toLocaleDateString() 
                                  : "N/A"}
                              </td>
                              <td>
                                <span className={`badge ${getStatusBadgeClass(item.status)}`}>
                                  {item.status || "N/A"}
                                </span>
                              </td>
                              <td>
                                {item.missing_fields?.length > 0 ? (
                                  <span className="badge bg-danger">
                                    {item.missing_fields.length} missing
                                  </span>
                                ) : (
                                  <span className="badge bg-success">Complete</span>
                                )}
                              </td>
                              <td>
                                <button
                                  className="btn btn-sm btn-link text-primary me-2"
                                  onClick={() => {
                                    setSelectedTeacher(item);
                                    setShowViewModal(true);
                                  }}
                                >
                                  <i className="fas fa-eye"></i>
                                </button>
                                <button
                                  className="btn btn-sm btn-link text-primary"
                                  onClick={() => {
                                    setSelectedTeacher(item);
                                    setShowEditModal(true);
                                  }}
                                >
                                  <i className="fas fa-edit"></i>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {renderPagination(teacherPage, setTeacherPage, teacherTotalPages, teacherTotal, "staff members")}
                  </>
                ) : (
                  <div className="text-center py-4">
                    <i className="fas fa-users fa-3x text-muted mb-3"></i>
                    <h5 className="text-muted">No Staff Requirements</h5>
                    <p className="text-muted">No staff requirements match your filters.</p>
                  </div>
                )}
              </div>
            )}

            {/* Children Requirements Section */}
            {(activeTab === "all" || activeTab === "immunization") && (
              <div className="mb-4">
                <div className="card-header bg-success bg-opacity-10">
                  <h2 className="h5 mb-0">Children Requirements</h2>
                </div>
                
                {filteredChildren.length > 0 ? (
                  <>
                    <div className="table-responsive">
                      <table className="table table-hover mb-0">
                        <thead className="table-light">
                          <tr>
                            <th scope="col">Child Name</th>
                            <th scope="col">ID</th>
                            <th scope="col">Enrollment Date</th>
                            <th scope="col">Status</th>
                            <th scope="col">Missing Fields</th>
                            <th scope="col">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredChildren.map((child) => (
                            <tr key={child.child_id}>
                              <td>
                                <div className="d-flex align-items-center">
                                  <div className="avatar-placeholder bg-success-bg text-success me-3">
                                    {child.full_name[0]?.toUpperCase() || "?"}
                                  </div>
                                  <div>
                                    <div className="fw-medium">
                                      {child.full_name}
                                      {child.missing_fields?.length > 0 && (
                                        <span className="badge bg-warning text-dark ms-2">Incomplete</span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </td>
                              <td>{child.child_id || "N/A"}</td>
                              <td>
                                {child.enrollment_date 
                                  ? new Date(child.enrollment_date).toLocaleDateString() 
                                  : "N/A"}
                              </td>
                              <td>
                                <span className={`badge ${child.status ? "bg-success" : "bg-warning text-dark"}`}>
                                  {child.status || "Pending"}
                                </span>
                              </td>
                              <td>
                                {child.missing_fields?.length > 0 ? (
                                  <div>
                                    <span className="badge bg-danger me-1">
                                      {child.missing_fields.length} missing
                                    </span>
                                    <small className="text-muted d-block mt-1">
                                      {child.missing_fields.slice(0, 3).join(", ")}
                                      {child.missing_fields.length > 3 && "..."}
                                    </small>
                                  </div>
                                ) : (
                                  <span className="badge bg-success">Complete</span>
                                )}
                              </td>
                              <td>
                                <button
                                  className="btn btn-sm btn-link text-primary me-2"
                                  onClick={() => {
                                    setSelectedChild(child);
                                    setShowChildViewModal(true);
                                  }}
                                >
                                  <i className="fas fa-eye"></i>
                                </button>
                                <button
                                  className="btn btn-sm btn-link text-primary"
                                  onClick={() => {
                                    setSelectedChild(child);
                                    setShowChildEditModal(true);
                                  }}
                                >
                                  <i className="fas fa-edit"></i>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {renderPagination(childPage, setChildPage, childTotalPages, childTotal, "children")}
                  </>
                ) : (
                  <div className="text-center py-4">
                    <i className="fas fa-child fa-3x text-muted mb-3"></i>
                    <h5 className="text-muted">No Children Requirements</h5>
                    <p className="text-muted">No children requirements match your filters.</p>
                  </div>
                )}
              </div>
            )}

            {/* Location Maintenance Section */}
            {(activeTab === "all" || activeTab === "maintenance") && (
              <div>
                <div className="card-header bg-warning bg-opacity-10">
                  <h2 className="h5 mb-0">Location Requirements</h2>
                </div>
                
                {filteredMaintenance.length > 0 ? (
                  <>
                    <div className="table-responsive">
                      <table className="table table-hover mb-0">
                        <thead className="table-light">
                          <tr>
                            <th scope="col">Location</th>
                            <th scope="col">Request Title</th>
                            <th scope="col">Reported Date</th>
                            <th scope="col">Priority</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredMaintenance.map((item) => (
                            <tr key={item.id}>
                              <td>{item.location || "N/A"}</td>
                              <td>{item.request_title || "N/A"}</td>
                              <td>
                                {item.date_reported 
                                  ? new Date(item.date_reported).toLocaleDateString() 
                                  : "N/A"}
                              </td>
                              <td>
                                <span className={`badge ${getPriorityBadgeClass(item.priority)}`}>
                                  {item.priority || "N/A"}
                                </span>
                              </td>
                              <td>
                                <span className={`badge ${getStatusBadgeClass(item.status)}`}>
                                  {item.status || "N/A"}
                                </span>
                              </td>
                              <td>
                                <button
                                  className="btn btn-sm btn-link text-primary me-2"
                                  onClick={() => {
                                    setSelectedMaintenance(item);
                                    setShowLocationViewModal(true);
                                  }}
                                >
                                  <i className="fas fa-eye"></i>
                                </button>
                                <button
                                  className="btn btn-sm btn-link text-primary"
                                  onClick={() => {
                                    setSelectedMaintenance(item);
                                    setShowLocationEditModal(true);
                                  }}
                                >
                                  <i className="fas fa-edit"></i>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {renderPagination(maintenancePage, setMaintenancePage, maintenanceTotalPages, maintenanceTotal, "maintenance items")}
                  </>
                ) : (
                  <div className="text-center py-4">
                    <i className="fas fa-tools fa-3x text-muted mb-3"></i>
                    <h5 className="text-muted">No Maintenance Requirements</h5>
                    <p className="text-muted">No maintenance requirements match your filters.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Modals (remain mostly the same with minor tweaks) */}
        {/* ... existing modal code ... */}
      </div>
    </div>
  );
};

// Helper functions
const getStatusBadgeClass = (status) => {
  switch(status?.toLowerCase()) {
    case "overdue": return "bg-danger";
    case "pending": return "bg-warning text-dark";
    case "in progress": return "bg-info";
    case "scheduled": return "bg-primary";
    case "completed": return "bg-success";
    default: return "bg-secondary";
  }
};

const getPriorityBadgeClass = (priority) => {
  switch(priority?.toLowerCase()) {
    case "high": return "bg-danger";
    case "medium": return "bg-warning text-dark";
    case "low": return "bg-success";
    default: return "bg-secondary";
  }
};

// Avatar placeholder styles
const avatarStyle = {
  width: '40px', 
  height: '40px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  fontWeight: '600'
};


export default Outstandingrequirement;