import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import { reusableColor } from "../reusableColor";
import html2pdf from 'html2pdf.js';
import { useDispatch, useSelector } from "react-redux";
import { addDocument, getDocuments } from "../../../redux/slices/documentSlice";
import { getUsers } from "../../../redux/slices/userSlice";
import { BASE_URL } from "../../../utils/config";
import axios from "axios";
import { FaFileAlt } from "react-icons/fa";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';


function DocumentCard({
  icon,
  iconBg,
  iconColor,
  title,
  type,
  uploadedFor,
  uploadDate,
  expiryDate,
  status,
  statusColor,
  onView, onDownload
}) {
  return (
    <div className="dv-document-card bg-white rounded-4 shadow-sm border mb-4 p-3">
      <div className="d-flex justify-content-between align-items-start">
        <div className="d-flex align-items-center">
          <div
            className={`d-flex align-items-center justify-content-center rounded-3 ${iconBg}`}
            style={{ width: 40, height: 40 }}
          >
            <i className={`bi ${icon} ${iconColor} fs-4`}></i>
          </div>
          <div className="ms-3">
            <h3 className="fs-6 fw-semibold text-truncate mb-1" style={{ maxWidth: 180 }}>
              {title}
            </h3>
            <p className="small text-secondary mb-0">{type}</p>
          </div>
        </div>
        <div className="d-flex align-items-center">
          <input type="checkbox" className="form-check-input dv-checkbox me-2" />
          <div className="dropdown">
            <button
              className="btn btn-link text-secondary p-0"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              <i className="bi bi-three-dots-vertical"></i>
            </button>
            <ul className="dropdown-menu dropdown-menu-end">
              <li>
                <a className="dropdown-item" href="#">
                  <i className="bi bi-eye me-2"></i>View
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="#">
                  <i className="bi bi-download me-2"></i>Download
                </a>
              </li>
              <li>
                <a className="dropdown-item text-danger" href="#">
                  <i className="bi bi-trash me-2"></i>Delete
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="mt-3">
        <div className="d-flex justify-content-between small text-secondary mb-1">
          <span>Uploaded For</span>
          <span>{uploadedFor}</span>
        </div>
        <div className="d-flex justify-content-between small text-secondary mb-1">
          <span>Upload Date</span>
          <span>{uploadDate}</span>
        </div>
        <div className="d-flex justify-content-between small text-secondary mb-1">
          <span>Expiry Date</span>
          <span>{expiryDate}</span>
        </div>
        <div className="d-flex justify-content-between align-items-center small mb-1">
          <span className="text-secondary">Status</span>
          <span className={`badge rounded-pill ${statusColor}`}>{status}</span>
        </div>
      </div>
      <div className="mt-3 d-flex gap-2">
        <button
          className="btn btn-sm flex-fill dv-btn text-white"
          style={{ backgroundColor: "#2ab7a9" }}
          onClick={onView}
        >
          <i className="bi bi-eye me-1"></i>View
        </button>

        <button
          className="btn btn-sm flex-fill dv-btn text-white"
          style={{ backgroundColor: "#2ab7a9" }}
          onClick={onDownload}
        >
          <i className="bi bi-download me-1"></i>Download
        </button>


      </div>
    </div>
  );
}

export default function DocumentsVault() {


  const [activeTab, setActiveTab] = useState("Teacher");
  const [showFilter, setShowFilter] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [showViewModal, setShowViewModal] = useState(false);

  const loggedInuser = localStorage.getItem("user_id");

  const [form, setForm] = useState({
    document_title: "",
    upload_for_user_id: "",
    upload_for_name: "fdsfgds",  // currently set to admin , TODO  - TO LoggedIn user
    expiry_date: "",
    submitted_by_user_id: loggedInuser,
    document_file: null,
  });


  const { documents, loading, error } = useSelector((state) => state.document);
  console.log("DOCUMENTS !! ", documents);
  const { user, loading: userLoading, error: userError } = useSelector((state) => state.user);
  console.log("users", user)




  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getDocuments());
  }, [dispatch]);

  useEffect(() => {
    dispatch(getUsers());
  },
    [dispatch])

  const handleFormChange = (e) => {
    const { name, value, files } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("document_title", form.document_title);
    formData.append("upload_for_user_id", form.upload_for_user_id);
    formData.append("expiry_date", form.expiry_date);
    formData.append("submitted_by_user_id", form.submitted_by_user_id);
    formData.append("document_file", form.document_file);


    //  const response = await axios.post( `${BASE_URL}/documents`,formData, {
    //   headers: { 
    //     "Content-Type": "multipart/form-data",
    //   },
    // })

    // console.log(response)

    // setDocument(response.data);

    // console.log(document);

    await dispatch(addDocument(formData));
    setShowModal(false);
    setForm({
      document_title: "",
      upload_for_user_id: "",
      expiry_date: "",
      submitted_by_user_id: "",
      document_file: null,
    });
  };

  console.log("SElected Doc".selectedDoc)

  const handleDownload = (doc) => {
    if (doc.document_url) {
      // Create a temporary anchor element
      const link = document.createElement('a');
      link.href = doc.document_url.trim(); // Remove any extra whitespace
      link.target = '_blank';
      link.download = doc.document_title || 'document'; // Use document title as filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const getDocumentsByType = () => {
    switch (activeTab) {
      case "Teacher":
        return documents.filter(doc => doc.upload_for_role === "teacher");
      case "child":
        return documents.filter(doc => doc.upload_for_role === "child");
      case "location":
        return documents.filter(doc => doc.upload_for_role === "location");
      default:
        return [];
    }
  };



  // const renderDocuments = () => {
  //   const filteredDocs = getDocumentsByType();

  //   if (loading) {
  //     return (
  //       <div className="text-center">
  //         <div className="spinner-border text-primary" role="status">
  //           <span className="visually-hidden">Loading...</span>
  //         </div>
  //       </div>
  //     );
  //   }

  //   if (error) {
  //     return (
  //       <div className="alert alert-danger" role="alert">
  //         {error}
  //       </div>
  //     );
  //   }

  //   if (!filteredDocs.length) {
  //     return (
  //       <div className="col-12 text-center">
  //         <p>No documents found for this category</p>
  //       </div>
  //     );
  //   }

  //   return filteredDocs.map((doc) => (
  //     <div className="col-12 col-md-6 col-xl-4" key={doc.document_id}>
  //       <DocumentCard
  //         id={doc.document_id}
  //         // title={doc.document_title}
  //         type={doc.document_url.split('.').pop().toUpperCase() + " Document"}
  //         uploadedFor={`${doc.upload_for_first_name} ${doc.upload_for_last_name}`}
  //         uploadDate={new Date(doc.created_at).toLocaleDateString()}
  //         expiryDate={new Date(doc.expiry_date).toLocaleDateString()}
  //         status={new Date(doc.expiry_date) > new Date() ? "Valid" : "Expired"}
  //         statusColor={new Date(doc.expiry_date) > new Date() ? "bg-success bg-opacity-25 text-success" : "bg-danger bg-opacity-25 text-danger"}
  //         icon={`bi-file-earmark-${doc.document_url.split('.').pop()}`}
  //         iconBg="bg-primary bg-opacity-10"
  //         iconColor="text-primary"
  //         onView={() => {
  //           setSelectedDoc(doc);
  //           setShowViewModal(true);
  //         }}
  //         onDownload={() => handleDownload(doc)}
  //       />
  //     </div>
  //   ));
  // };

  // Add these helper functions inside the DocumentsVault component
  function renderStaffDocuments(staffDocuments) {
    if (!staffDocuments || staffDocuments.length === 0) {
      return <div className="col-12 text-center"><p>No staff documents found.</p></div>;
    }
    const docTypes = [
      { key: 'medical_form', label: 'Medical Form' },
      { key: 'credentials', label: 'Credentials' },
      { key: 'cbc_worksheet', label: 'CBC Worksheet' },
      { key: 'auth_affirmation_form', label: 'Auth Affirmation Form' },
      { key: 'mandated_reporter_cert', label: 'Mandated Reporter Cert' },
      { key: 'preventing_sids_cert', label: 'Preventing SIDS Cert' },
    ];
    return staffDocuments.flatMap((doc, idx) =>
      docTypes.filter(type => doc[type.key])
        .map(type => (
          <div className="col-12 col-md-6 col-xl-4" key={type.key + idx}>
            <DocumentCard
              title={type.label}
              type={type.label}
              uploadedFor={doc.teacher_name || `Teacher #${doc.teacher_id}`}
              uploadDate={"-"}
              expiryDate={"-"}
              status={"Valid"}
              statusColor={"bg-success bg-opacity-25 text-success"}
              icon={"bi-file-earmark-pdf"}
              iconBg="bg-primary bg-opacity-10"
              iconColor="text-primary"
              onView={() => window.open(doc[type.key], '_blank')}
              onDownload={() => {
                const link = document.createElement('a');
                link.href = doc[type.key];
                link.target = '_blank';
                link.download = type.label;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
            />
          </div>
        ))
    );
  }

  function renderChildDocuments(childDocuments) {
    if (!childDocuments || childDocuments.length === 0) {
      return <div className="col-12 text-center"><p>No child documents found.</p></div>;
    }
    const docTypes = [
      { key: 'medical_form_url', label: 'Medical Form' },
      { key: 'immunization_record_url', label: 'Immunization Record' },
      { key: 'lunch_form_url', label: 'Lunch Form' },
      { key: 'agreement_docs_url', label: 'Agreement Docs' },
    ];
    return childDocuments.flatMap((doc, idx) =>
      docTypes.filter(type => doc[type.key])
        .map(type => {
          // Some fields may be arrays or strings
          let urls = doc[type.key];
          if (typeof urls === 'string' && urls.startsWith('[')) {
            try { urls = JSON.parse(urls); } catch { urls = []; }
          }
          if (!Array.isArray(urls)) urls = [urls];
          return urls.filter(Boolean).map((url, i) => (
            <div className="col-12 col-md-6 col-xl-4" key={type.key + idx + i}>
              <DocumentCard
                title={type.label}
                type={type.label}
                uploadedFor={doc.child_name || `Child #${doc.child_id}`}
                uploadDate={"-"}
                expiryDate={"-"}
                status={"Valid"}
                statusColor={"bg-success bg-opacity-25 text-success"}
                icon={"bi-file-earmark-pdf"}
                iconBg="bg-primary bg-opacity-10"
                iconColor="text-primary"
                onView={() => window.open(url, '_blank')}
                onDownload={() => {
                  const link = document.createElement('a');
                  link.href = url;
                  link.target = '_blank';
                  link.download = type.label;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                }}
              />
            </div>
          ));
        })
    ).flat();
  }

  function renderLocationDocuments(locationDocuments) {
    if (!locationDocuments || locationDocuments.length === 0) {
      return <div className="col-12 text-center"><p>No location documents found.</p></div>;
    }
    return locationDocuments.map((doc, idx) => (
      <div className="col-12 col-md-6 col-xl-4" key={doc.id || idx}>
        <DocumentCard
          title={doc.type || 'Location Document'}
          type={doc.type || 'Location Document'}
          uploadedFor={doc.remarks || '-'}
          uploadDate={doc.date ? new Date(doc.date).toLocaleDateString() : '-'}
          expiryDate={"-"}
          status={"Valid"}
          statusColor={"bg-success bg-opacity-25 text-success"}
          icon={"bi-file-earmark-pdf"}
          iconBg="bg-primary bg-opacity-10"
          iconColor="text-primary"
          onView={() => window.open(doc.document_url, '_blank')}
          onDownload={() => {
            const link = document.createElement('a');
            link.href = doc.document_url;
            link.target = '_blank';
            link.download = doc.type || 'Location Document';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }}
        />
      </div>
    ));
  }

  // Calculate document counts for each tab
  const staffDocCount = documents.staff_documents
    ? documents.staff_documents.reduce((acc, doc) => {
      const docTypes = [
        'medical_form',
        'credentials',
        'cbc_worksheet',
        'auth_affirmation_form',
        'mandated_reporter_cert',
        'preventing_sids_cert',
      ];
      return (
        acc + docTypes.filter(type => doc[type]).length
      );
    }, 0)
    : 0;

  const childDocCount = documents.child_documents
    ? documents.child_documents.reduce((acc, doc) => {
      const docTypes = [
        'medical_form_url',
        'immunization_record_url',
        'lunch_form_url',
        'agreement_docs_url',
      ];
      let count = 0;
      docTypes.forEach(type => {
        let urls = doc[type];
        if (typeof urls === 'string' && urls.startsWith('[')) {
          try { urls = JSON.parse(urls); } catch { urls = []; }
        }
        if (!Array.isArray(urls)) urls = [urls];
        count += urls.filter(Boolean).length;
      });
      return acc + count;
    }, 0)
    : 0;

  const locationDocCount = documents.location_documents
    ? documents.location_documents.length
    : 0;

  return (
    <div className="dv-vault bg-light min-vh-100">
      {/* Filter Panel */}
      {showFilter && (
        <div className="bg-white border-bottom p-3">
          <div className="row g-3">
            <div className="col-12 col-md-3">
              <label className="form-label">Document Type</label>
              <select className="form-select">
                <option value="">All Types</option>
                <option value="id">ID Document</option>
                <option value="certificate">Certificate</option>
                <option value="form">Form</option>
                <option value="report">Report</option>
                <option value="policy">Policy</option>
              </select>
            </div>
            <div className="col-12 col-md-3">
              <label className="form-label">Status</label>
              <select className="form-select">
                <option value="">All Status</option>
                <option value="valid">Valid</option>
                <option value="expired">Expired</option>
                <option value="pending">Pending</option>
              </select>
            </div>
            <div className="col-12 col-md-4">
              <label className="form-label">Date Range</label>
              <div className="d-flex gap-2">
                <input type="date" className="form-control" />
                <input type="date" className="form-control" />
              </div>
            </div>
            <div className="col-12 col-md-2 d-flex align-items-end">
              <button className="btn btn-success w-100">Apply Filters</button>
            </div>
          </div>
          <div className="d-flex justify-content-end mt-2">
            <button className="btn btn-link text-secondary">
              <i className="bi bi-arrow-clockwise me-1"></i> Reset Filters
            </button>
          </div>
        </div>
      )}

      {/* Tabs Header Section */}
      <div className="bg-white border-bottom px-3 py-3">
        <div className="row align-items-center mb-2">
          {/* Heading */}
          <div className="col-12 col-md-6 mb-2 mb-md-0">
            <h4 className="fw-semibold mb-0 text-md-start text-center" style={{ color: "#2ab7a9" }}>
              Documents Vault
            </h4>
          </div>

          {/* Add Button */}
          <div className="col-12 col-md-6 text-md-end text-center">
            <Button
              onClick={() => setShowModal(true)}
              className="w-30 w-md-auto"
              style={{ backgroundColor: reusableColor.customTextColor }}
            >
              <i className="bi bi-plus-lg me-2"></i>Add Document
            </Button>
          </div>
        </div>

        {/* Tabs */}
        {/* <div className="d-flex flex-wrap border-top pt-2">
          <button
            className={`dv-tab-btn flex-fill py-3 px-2 border-0 bg-transparent fw-medium ${activeTab === "Teacher" ? "border-bottom border-success text-success" : "text-secondary"}`}
            onClick={() => setActiveTab("Teacher")}
          >
            Staff Documents
            <span className="ms-2 badge bg-light text-secondary fw-normal">{staffDocCount}</span>
          </button>
          <button
            className={`dv-tab-btn flex-fill py-3 px-2 border-0 bg-transparent fw-medium ${activeTab === "child" ? "border-bottom border-success text-success" : "text-secondary"}`}
            onClick={() => setActiveTab("child")}
          >
            Child Documents
            <span className="ms-2 badge bg-light text-secondary fw-normal">{childDocCount}</span>
          </button>
          <button
            className={`dv-tab-btn flex-fill py-3 px-2 border-0 bg-transparent fw-medium ${activeTab === "location" ? "border-bottom border-success text-success" : "text-secondary"}`}
            onClick={() => setActiveTab("location")}
          >
            Location Documents
            <span className="ms-2 badge bg-light text-secondary fw-normal">{locationDocCount}</span>
          </button>
        </div> */}
      </div>


      {/* {showModal && (
        <div className="modal fade show d-block" tabIndex="-1" style={{ background: "rgba(0,0,0,0.3)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Upload Document</h5>
                <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
              </div>
              <div className="modal-body">
                <form>
                  <div className="mb-3">
                    <label className="form-label">Document Title</label>
                    <input type="text" className="form-control" placeholder="Enter document title" />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Document File</label>
                    <input type="file" 
                    className="form-control"
                    
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Upload For</label>
                    <input type="text" className="form-control"
                    value=""
                     placeholder="Teacher/Child/Location Name" />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Expiry Date</label>
                    <input type="date" className="form-control" />
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </Button>
                <Button variant="success">
                  Upload
                </Button>
              </div>
            </div>
          </div>
        </div>
      )} */}

      {showModal && (
        <div
          className="modal fade show d-block"
          tabIndex="-1"
          style={{ background: "rgba(0,0,0,0.3)" }}
        >
          <div className="modal-dialog">
            <form onSubmit={handleFormSubmit} encType="multipart/form-data">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Upload Document</h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={() => setShowModal(false)}
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="mb-3">
                    <label className="form-label">Document Title</label>
                    <input
                      type="text"
                      name="document_title"
                      value={form.document_title}
                      // onChange={(e)=> setForm(e.target.value)}
                      onChange={handleFormChange}
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Upload For User ID</label>
                    <select
                      name="upload_for_user_id"

                      value={form.upload_for_user_id}
                      onChange={handleFormChange}
                      className="form-control"

                    >
                      <option value="">Select User</option>
                      {
                        user.map((user) => (
                          <option key={user.user_id} value={user.user_id}>{user.first_name} {user.last_name}</option>
                        ))
                      }
                    </select>

                  </div>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="Expiry Date"
                      value={form.expiry_date ? dayjs(form.expiry_date) : null}
                      onChange={(newValue) =>
                        handleFormChange({
                          target: {
                            name: "expiry_date",
                            value: newValue ? dayjs(newValue).format("YYYY-MM-DD") : ""
                          }
                        })
                      }
                      slotProps={{
                        textField: {
                          variant: "outlined",
                          fullWidth: true,
                          required: true,
                          InputProps: {
                            className: "form-control", // applies Bootstrap style
                            style: { height: "38px", fontSize: "14px" }, // matches other inputs
                          },
                          inputProps: {
                            placeholder: "YYYY-MM-DD",
                          },
                        },
                      }}
                    />
                  </LocalizationProvider>
                  {/* <div className="mb-3">
                    <label className="form-label">Submitted By User ID</label>
                    <input
                      type="text"
                      name="submitted_by_user_id"
                      value={form.submitted_by_user_id}
                      onChange={handleFormChange}
                      className="form-control"
                      required
                    />
                  </div> */}
                  <div className="mb-3">
                    <label className="form-label">Document File</label>
                    <input
                      type="file"
                      name="document_file"
                      onChange={handleFormChange}
                      className="form-control"
                      required
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <Button
                    variant="secondary"
                    onClick={() => setShowModal(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" variant="success">
                    Upload
                  </Button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}




      {/* Main Content */}
      {/* <div className="container py-4">
        <div className="row g-4">
          {activeTab === "Teacher" && renderStaffDocuments(documents.staff_documents)}
          {activeTab === "child" && renderChildDocuments(documents.child_documents)}
          {activeTab === "location" && renderLocationDocuments(documents.location_documents)}
        </div>

      </div> */}


      {showViewModal && selectedDoc && (
        <div className="modal fade show d-block" style={{ backgroundColor: "rgba(0,0,0,0.4)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              {/* Modal Header with custom theme color */}
              <div className="modal-header text-white" style={{ backgroundColor: "#2ab7a9" }}>
                <h5 className="modal-title">{selectedDoc.document_title} - Details</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => {
                    setShowViewModal(false);
                    setSelectedDoc(null); // Clear selected doc
                  }}
                ></button>
              </div>

              <div className="modal-body">
                <p><strong>Uploaded For:</strong> {selectedDoc.upload_for_first_name}</p>
                {/* <p><strong>Type:</strong> {selectedDoc.type}</p> */}
                <p><strong>Upload Date:</strong> {new Date(selectedDoc.expiry_date).toLocaleDateString()}</p>
                <p><strong>Expiry Date:</strong>{new Date(selectedDoc.created_at).toLocaleDateString()}</p>

                {/* <p><strong>Status:</strong> <span className={`badge ${selectedDoc.statusColor}`}>{selectedDoc.status}</span></p> */}

                <a
                  target="_blank" href={(selectedDoc?.document_url)}


                  className="text-decoration-none"
                >
                  {/* <FaFileAlt color="#2ab7a9" size={20} /> */}
                  <i className="fa-solid fa-file-pdf" style={{ color: "#2ab7a9", fontSize: "32px" }} ></i>
                </a>
              </div>

              <div className="modal-footer">
                <Button
                  variant="secondary"
                  onClick={() => {
                    setShowViewModal(false);
                    setSelectedDoc(null); // modal close and clear state
                  }}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}



    </div>
  );
}