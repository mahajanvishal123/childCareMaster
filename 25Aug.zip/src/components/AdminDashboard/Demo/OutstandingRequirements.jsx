import React from 'react'

const OutstandingRequirements = () => {
  return (
    <div>OutstandingRequirements</div>
  )
}

export default OutstandingRequirements