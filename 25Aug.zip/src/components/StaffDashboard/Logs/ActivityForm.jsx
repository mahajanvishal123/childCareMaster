import React, { useState } from "react";
import axios from "axios";
import { BASE_URL } from "../../../utils/config"; // Adjust path as needed

const ActivityForm = ({ child, onSuccess }) => {
  const [activity, setActivity] = useState("");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const formatTimeWithDate = (time) => {
    const today = new Date();
    const datePart = today.toISOString().split("T")[0]; // YYYY-MM-DD
    return `${datePart} ${time}:00`; // "YYYY-MM-DD HH:mm:00"
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        child_id: child.child_id,
        activity,
        time: formatTimeWithDate(time),
        notes,
      };

      const response = await axios.post(`${BASE_URL}/activities`, payload, {
        headers: { "Content-Type": "application/json" },
      });

      alert("✅ Activity log saved successfully!");
      if (onSuccess) onSuccess(response.data);

      // Reset form
      setActivity("");
      setTime("");
      setNotes("");
    } catch (err) {
      console.error("Error saving activity log:", err);
      alert("❌ Failed to save activity log. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-2">
        <label>Activity</label>
        <input
          className="form-control"
          value={activity}
          onChange={(e) => setActivity(e.target.value)}
          required
        />
      </div>
      <div className="mb-2">
        <label>Time</label>
        <input
          type="time"
          className="form-control"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          required
        />
      </div>
      <div className="mb-2">
        <label>Notes</label>
        <textarea
          className="form-control"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
      <button className="btn btn-primary" type="submit" disabled={loading}>
        {loading ? "Saving..." : "Save Activity Log"}
      </button>
    </form>
  );
};

export default ActivityForm;
