import React, { useState } from "react";
import axios from "axios";
import { BASE_URL } from "../../../utils/config"; // adjust path as needed

const MealsForm = ({ child, onSuccess }) => {
  const [meal, setMeal] = useState("Breakfast");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Compose full datetime string for meal_time
      const today = new Date().toISOString().split('T')[0];
      const fullMealTime = `${today}T${time}:00`;

      const payload = {
        child_id: child.child_id,
        meal_type: meal,
        meal_time: fullMealTime, // <-- send full datetime
        notes,
      };

      const res = await axios.post(`${BASE_URL}/meal/add`, payload, {
        headers: { "Content-Type": "application/json" },
      });

      alert("✅ Meal log saved successfully!");
      if (onSuccess) onSuccess(res.data);

      // Reset form
      setMeal("Breakfast");
      setTime("");
      setNotes("");
    } catch (error) {
      console.error("Error saving meal log:", error);
      alert("❌ Failed to save meal log. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-2">
        <label>Meal</label>
        <select
          className="form-control"
          value={meal}
          onChange={(e) => setMeal(e.target.value)}
        >
          <option value="Breakfast">Breakfast</option>
          <option value="Lunch">Lunch</option>
          <option value="Snack">Snack</option>
          <option value="Dinner">Dinner</option>
        </select>
      </div>
      <div className="mb-2">
        <label>Time</label>
        <input
          type="time"
          className="form-control"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          required
        />
      </div>
      <div className="mb-2">
        <label>Notes</label>
        <textarea
          className="form-control"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
      <button className="btn btn-primary" type="submit" disabled={loading}>
        {loading ? "Saving..." : "Save Meal Log"}
      </button>
    </form>
  );
};

export default MealsForm;
