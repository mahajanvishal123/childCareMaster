import React, { useState } from "react";
import axios from "axios";
import { BASE_URL } from "../../../utils/config";

const NotesForm = ({ child, teacherId, onSuccess }) => {
  const [category, setCategory] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!category || !note) {
      alert("Please fill all required fields.");
      return;
    }
    setLoading(true);
    try {
      const res = await axios.post(`${BASE_URL}/notes`, {
        child_id: child?.child_id,
        teacher_id: child?.assigned_teacher_id,
        note,
        category,
      });
      if (res.status === 201) {
        alert("Note added successfully!");
        setCategory("");
        setNote("");
        if (onSuccess) onSuccess();
      } else {
        alert("Failed to add note.");
      }
    } catch (err) {
      alert("Error adding note.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-2">
        <label>Category</label>
        <input
          className="form-control"
          value={category}
          onChange={e => setCategory(e.target.value)}
          required
          placeholder="e.g. Activity, Behavior, Health"
        />
      </div>
      <div className="mb-2">
        <label>Note</label>
        <textarea
          className="form-control"
          value={note}
          onChange={e => setNote(e.target.value)}
          required
        />
      </div>
      <button className="btn btn-primary" type="submit" disabled={loading}>
        {loading ? "Saving..." : "Save Note"}
      </button>
    </form>
  );
};

export default NotesForm;