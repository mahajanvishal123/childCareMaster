import React, { useState } from "react";
import axios from "axios";
import { BASE_URL } from "../../../utils/config";



const SleepLogForm = ({ child,  onSuccess }) => {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  console.log("SleepLogForm rendered with child:", child);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        child_id: child.child_id, // assuming child prop has id
        classroom_id: child.assigned_classroom || "", // passed as prop
        nap_start: start,
        nap_end: end,
        notes: notes
      };

      const res = await axios.post(`${BASE_URL}/safety/sleep-logs`, payload, {
        headers: { "Content-Type": "application/json" }
      });

      console.log("Sleep log saved:", res.data);
      if (onSuccess) onSuccess(res.data);

      // Reset form
      setStart("");
      setEnd("");
      setNotes("");
    } catch (error) {
      console.error("Error saving sleep log:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-2">
        <label>Start Time</label>
        <input
          type="time"
          className="form-control"
          value={start}
          onChange={(e) => setStart(e.target.value)}
          required
        />
      </div>
      <div className="mb-2">
        <label>End Time</label>
        <input
          type="time"
          className="form-control"
          value={end}
          onChange={(e) => setEnd(e.target.value)}
          required
        />
      </div>
      <div className="mb-2">
        <label>Notes</label>
        <textarea
          className="form-control"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
      <button className="btn btn-primary" type="submit" disabled={loading}>
        {loading ? "Saving..." : "Save Sleep Log"}
      </button>
    </form>
  );
};

export default SleepLogForm;
