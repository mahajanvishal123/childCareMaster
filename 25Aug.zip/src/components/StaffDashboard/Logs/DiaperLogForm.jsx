import React, { useState } from "react";
import axios from "axios";
import { BASE_URL } from "../../../utils/config";


const DiaperLogForm = ({ child, classroomId, changedBy, onSuccess }) => {
  const [time, setTime] = useState("");
  const [type, setType] = useState("Wet");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
         child_id: child.child_id, // assuming child prop has id
        classroom_id: child.assigned_classroom || "", // passed as prop
        time,
        changed_by: child.assigned_teacher_id || "", // pass in the name/id of the staff
        type,
        notes
      };

      const res = await axios.post(`${BASE_URL}/safety/diaper-logs`, payload, {
        headers: { "Content-Type": "application/json" }
      });

      alert("✅ Diaper log saved successfully!");
      if (onSuccess) onSuccess(res.data);

      // Reset form
      setTime("");
      setType("Wet");
      setNotes("");
    } catch (error) {
      console.error("Error saving diaper log:", error);
      alert("❌ Failed to save diaper log. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-2">
        <label>Time</label>
        <input
          type="time"
          className="form-control"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          required
        />
      </div>
      <div className="mb-2">
        <label>Type</label>
        <select
          className="form-control"
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          <option>Wet</option>
          <option>Soiled</option>
          <option>Both</option>
        </select>
      </div>
      <div className="mb-2">
        <label>Notes</label>
        <textarea
          className="form-control"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
      <button className="btn btn-primary" type="submit" disabled={loading}>
        {loading ? "Saving..." : "Save Diaper Log"}
      </button>
    </form>
  );
};

export default DiaperLogForm;
