export const reusableColor = {
  customTextColor: "rgb(42, 183, 169)",
};