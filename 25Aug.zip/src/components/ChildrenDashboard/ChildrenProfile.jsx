// import React, { useEffect, useState } from 'react';
// import { Row, Col, Button, Form, Card, Nav } from 'react-bootstrap';
// import {
//   FaUser,
//   FaMapMarkerAlt,
//   FaPhone,
//   FaCamera,
//   FaUserCircle,
// } from 'react-icons/fa';
// import { RiBook3Fill, RiBookLine, RiFileUploadFill, RiFileUploadLine } from 'react-icons/ri';
// import { reusableColor } from '../ReusableComponent/reusableColor';
// import axios from 'axios';
// import { BASE_URL } from '../../utils/config';

// const ChildrenProfile = () => {
//   const [isEditing, setIsEditing] = useState(false);
//   const [activeSection, setActiveSection] = useState('personal');
//   const [profile, setProfile] = useState({});

//   useEffect(() => {

//     const fetchchildrendetail = async () => {
//       const user_id = localStorage.getItem("user_id");
//       const response = await axios.get(`${BASE_URL}/children/${user_id}`);

//       console.log(response?.data?.child);


//       if (response?.data?.child) {
//         setProfile(response?.data?.child);
//       }
//     }

//     fetchchildrendetail();
//   }, []);

//   // const [profile, setProfile] = useState({
//   //   fullName: 'John Anderson',
//   //   employeeId: 'EMP-2025-0042',
//   //   email: 'john.anderson@school.edu',
//   //   phone: '(555) 123-4567',
//   //   role: 'Student',
//   //   department: 'Kindergarten',
//   //   classroom: 'Room 101',
//   //   floor: '2nd Floor',
//   //   contactName: 'Jane Doe',
//   //   contactPhone: '(555) 987-6543',
//   //   contactRelation: 'Mother',
//   //   motherName: 'Jane Doe',
//   //   fatherName: 'Michael Anderson',
//   //   motherCell: '(555) 987-1234',
//   //   fatherCell: '(555) 654-3210',
//   //   motherWorkplace: 'ABC Corp',
//   //   fatherWorkplace: 'XYZ Inc',
//   // });

//   const [backupProfile, setBackupProfile] = useState(profile);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setProfile((prev) => ({ ...prev, [name]: value }));
//   };

//   const handleEdit = () => {
//     setBackupProfile(profile);
//     setIsEditing(true);
//   };

//   const handleCancel = () => {
//     setProfile(backupProfile);
//     setIsEditing(false);
//   };

//   const handleSave = () => {
//     console.log('Saved:', profile);
//     setIsEditing(false);
//   };

//   return (
//     <div style={{ minHeight: '80vh', padding: '20px', display: 'flex', justifyContent: 'center' }}>
//       <Card className="shadow-sm w-100" style={{ maxWidth: '1200px', borderRadius: '10px' }}>
//         <Card.Body>
//           <div className="d-flex justify-content-between align-items-center mb-4">
//             <h4 className="fw-bold mb-0" style={{ color: reusableColor.customTextColor }}>Child Profile</h4>
//             {!isEditing ? (
//               <Button size="sm" style={{ backgroundColor: reusableColor.customTextColor, border: 'none' }} onClick={handleEdit}>Edit Profile</Button>
//             ) : (
//               <Button size="sm" variant="secondary" onClick={handleCancel}>Cancel</Button>
//             )}
//           </div>

//           <Row>
//             <Col xs={12} md={4} className="border-end mb-4 mb-md-0 text-center">
//               <div className="mb-3">
//                 <div className="position-relative d-inline-block">
//                   {profile?.photo_url ? (
//                     <img
//                       src={profile.photo_url}
//                       alt="Child"
//                       className="rounded-circle"
//                       style={{ width: 100, height: 100, objectFit: 'cover', border: '3px solid #2ab7a9' }}
//                     />
//                   ) : (
//                     <FaUserCircle size={90} color="#2ab7a9" style={{ border: '3px solid #2ab7a9', borderRadius: '50%', padding: '5px', backgroundColor: '#fff' }} />
//                     // <FaUserCircle size={100} color="#2ab7a9" />
//                   )}

//                   <div className="position-absolute bottom-0 end-0 bg-white rounded-circle p-1" style={{ border: '2px solid #2ab7a9' }}>
//                     <FaCamera size={14} color="#1A2423FF" />
//                   </div>
//                 </div>
//                 <h6 className="fw-bold mt-2 mb-0">{profile?.full_name}</h6>
//                 <p className="text-muted">{profile?.role_name}</p>
//               </div>

//               <Nav className="flex-column">
//                 <Nav.Link active={activeSection === 'personal'} onClick={() => setActiveSection('personal')} className="mb-2 rounded" style={{ backgroundColor: activeSection === 'personal' ? reusableColor.customTextColor : '', color: activeSection === 'personal' ? 'white' : 'black' }}>
//                   <FaUser className="me-2" /> Personal Info
//                 </Nav.Link>
//                 <Nav.Link active={activeSection === 'location'} onClick={() => setActiveSection('location')} className="mb-2 rounded" style={{ backgroundColor: activeSection === 'location' ? reusableColor.customTextColor : '', color: activeSection === 'location' ? 'white' : 'black' }}>
//                   <FaMapMarkerAlt className="me-2" /> Location/Classroom
//                 </Nav.Link>
//                 <Nav.Link active={activeSection === 'emergency'} onClick={() => setActiveSection('emergency')} className="mb-2 rounded" style={{ backgroundColor: activeSection === 'emergency' ? reusableColor.customTextColor : '', color: activeSection === 'emergency' ? 'white' : 'black' }}>
//                   <FaPhone className="me-2" /> Emergency Contact
//                 </Nav.Link>
//                 <Nav.Link active={activeSection === 'parents'} onClick={() => setActiveSection('parents')} className="mb-2 rounded" style={{ backgroundColor: activeSection === 'parents' ? reusableColor.customTextColor : '', color: activeSection === 'parents' ? 'white' : 'black' }}>
//                   <FaUser className="me-2" /> Parent Details
//                 </Nav.Link>
//                 <Nav.Link active={activeSection === 'documents'} onClick={() => setActiveSection('documents')} className="mb-2 rounded" style={{ backgroundColor: activeSection === 'documents' ? reusableColor.customTextColor : '', color: activeSection === 'documents' ? 'white' : 'black' }}>
//                   <RiFileUploadFill className="me-2" /> Documents
//                 </Nav.Link>
//                 <Nav.Link active={activeSection === 'classroom'} onClick={() => setActiveSection('classroom')} className="mb-2 rounded" style={{ backgroundColor: activeSection === 'classroom' ? reusableColor.customTextColor : '', color: activeSection === 'classroom' ? 'white' : 'black' }}>
//                   <RiBook3Fill className="me-2" /> Classroom
//                 </Nav.Link>
//               </Nav>
//             </Col>

//             <Col xs={12} md={8}>
//               <Form>
//                 {activeSection === 'personal' && (
//                   <Card className="mb-3">
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Personal Information</Card.Header>
//                     <Card.Body>
//                       <Row className="mb-3">
//                         <Col md={6}>
//                           <Form.Label>Full Name</Form.Label>
//                           <Form.Control name="full_name" value={profile?.full_name} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         {/* <Col md={6}>
//                           <Form.Label>Employee ID</Form.Label>
//                           <Form.Control name="employeeId" value={profile?.employeeId} onChange={handleChange} disabled={!isEditing} />
//                         </Col> */}
//                       </Row>
//                       <Row>
//                         <Col md={6}>
//                           <Form.Label>Email</Form.Label>
//                           <Form.Control name="email" value={profile?.email} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Phone</Form.Label>
//                           <Form.Control name="user_phone" value={profile?.user_phone} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                       </Row>
//                       <Row className="mt-3">
//                         <Col md={6}>
//                           <Form.Label>Role</Form.Label>
//                           <Form.Control name="role_name" value={profile?.role_name} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Department</Form.Label>
//                           <Form.Control name="department" value={profile?.department} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                       </Row>
//                     </Card.Body>
//                   </Card>
//                 )}

//                 {activeSection === 'location' && (
//                   <Card className="mb-3">
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Location / Classroom</Card.Header>
//                     <Card.Body>
//                       <Row>
//                         <Col md={6}>
//                           <Form.Label>Classroom</Form.Label>
//                           <Form.Control name="assigned_classroom" value={profile?.assigned_classroom} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Floor</Form.Label>
//                           <Form.Control name="floor" value={profile?.floor} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                       </Row>
//                     </Card.Body>
//                   </Card>
//                 )}

//                 {/* {activeSection === 'emergency' && (
//                   <Card className="mb-3">
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Emergency Contact</Card.Header>
//                     <Card.Body>
//                       <Row>
//                         <Col md={6}>
//                           <Form.Label>Contact Name</Form.Label>
//                           <Form.Control name="contactName" value={profile?.contactName} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Contact Phone</Form.Label>
//                           <Form.Control name="contactPhone" value={profile?.contactPhone} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Relationship</Form.Label>
//                           <Form.Control name="contactRelation" value={profile?.contactRelation} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                       </Row>
//                     </Card.Body>
//                   </Card>
//                 )} */}
//                 {activeSection === 'emergency' && profile?.emergency_contacts?.map((contact, index) => (
//                   <Card className="mb-3" key={contact.id || index}>
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>
//                       Emergency Contact {index + 1}
//                     </Card.Header>
//                     <Card.Body>
//                       <Row>
//                         <Col md={6}>
//                           <Form.Label>Contact Name</Form.Label>
//                           <Form.Control
//                             name={`contactName_${index}`}
//                             value={contact.name}
//                             onChange={(e) => handleChange(e, index, 'name')}
//                             disabled={!isEditing}
//                           />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Contact Phone</Form.Label>
//                           <Form.Control
//                             name={`contactPhone_${index}`}
//                             value={contact.phone}
//                             onChange={(e) => handleChange(e, index, 'phone')}
//                             disabled={!isEditing}
//                           />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Relationship</Form.Label>
//                           <Form.Control
//                             name={`contactRelation_${index}`}
//                             value={contact.relationship_to_child}
//                             onChange={(e) => handleChange(e, index, 'relationship_to_child')}
//                             disabled={!isEditing}
//                           />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Address</Form.Label>
//                           <Form.Control
//                             name={`contactAddress_${index}`}
//                             value={contact.address}
//                             onChange={(e) => handleChange(e, index, 'address')}
//                             disabled={!isEditing}
//                           />
//                         </Col>
//                       </Row>
//                     </Card.Body>
//                   </Card>
//                 ))}


//                 {activeSection === 'parents' && (
//                   <Card className="mb-3">
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Parent Details</Card.Header>
//                     <Card.Body>
//                       <Row>
//                         <Col md={6}>
//                           <Form.Label>Mother's Name</Form.Label>
//                           <Form.Control name="mother_name" value={profile?.mother_name || ''} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Father's Name</Form.Label>
//                           <Form.Control name="father_name" value={profile?.father_name || ''} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Mother's Cell</Form.Label>
//                           <Form.Control name="mother_cell" value={profile?.mother_cell || ''} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Father's Cell</Form.Label>
//                           <Form.Control name="father_cell" value={profile?.father_cell || ''} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Mother's Workplace</Form.Label>
//                           <Form.Control name="mother_workplace" value={profile?.mother_workplace || ''} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                         <Col md={6}>
//                           <Form.Label>Father's Workplace</Form.Label>
//                           <Form.Control name="father_workplace" value={profile?.father_workplace || ''} onChange={handleChange} disabled={!isEditing} />
//                         </Col>
//                       </Row>
//                     </Card.Body>
//                   </Card>
//                 )}

//                 {activeSection === 'documents' && (
//                   <Card className="mb-3">
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Documents</Card.Header>
//                     <Card.Body>
//                       <Form.Group className="mb-3">
//                         <Form.Label>Medical Form</Form.Label>
//                         <Form.Control type="file" disabled={!isEditing} />
//                       </Form.Group>
//                       <Form.Group className="mb-3">
//                         <Form.Label>Immunization Record</Form.Label>
//                         <Form.Control type="file" disabled={!isEditing} />
//                       </Form.Group>
//                       <Form.Group>
//                         <Form.Label>Authorization & Affirmation Form</Form.Label>
//                         <Form.Control type="file" disabled={!isEditing} />
//                       </Form.Group>
//                     </Card.Body>
//                   </Card>
//                 )}

//                 {activeSection === 'classroom' && (
//                   <Card className="mb-3">
//                     <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Classroom Assignment</Card.Header>
//                     <Card.Body>
//                       <Form.Label>Assigned Classroom</Form.Label>
//                       <Form.Select name="classroom" value={profile?.classroom} onChange={handleChange} disabled={!isEditing}>
//                         <option value="">Select a classroom</option>
//                         <option value="Room 101">Room 101</option>
//                         <option value="Room 102">Room 102</option>
//                         <option value="Room 103">Room 103</option>
//                         <option value="Room 104">Room 104</option>
//                       </Form.Select>
//                     </Card.Body>
//                   </Card>
//                 )}

//                 {isEditing && (
//                   <div className="text-end">
//                     <Button onClick={handleSave} style={{ backgroundColor: reusableColor.customTextColor, border: 'none' }}>
//                       Save Changes
//                     </Button>
//                   </div>
//                 )}
//               </Form>
//             </Col>
//           </Row>
//         </Card.Body>
//       </Card>
//     </div>
//   );
// };

// export default ChildrenProfile;

import React, { useEffect, useState } from 'react';
import { Row, Col, Button, Form, Card, Nav } from 'react-bootstrap';
import { FaUser, FaMapMarkerAlt, FaPhone, FaCamera, FaUserCircle } from 'react-icons/fa';
import { RiBook3Fill, RiFileUploadFill } from 'react-icons/ri';
import { reusableColor } from '../ReusableComponent/reusableColor';
import axios from 'axios';
import { BASE_URL } from '../../utils/config';
import { useDispatch, useSelector } from 'react-redux';
import { getClassroom } from '../../redux/slices/classRoomSlice';

const ChildrenProfile = () => {
  const dispatch = useDispatch();
  const [isEditing, setIsEditing] = useState(false);
  const [activeSection, setActiveSection] = useState('personal');
  const [profile, setProfile] = useState({});
  const [backupProfile, setBackupProfile] = useState({});

  const { classroom } = useSelector((state) => state.classroom);

  useEffect(() => {
    dispatch(getClassroom());
  }, [dispatch]);


  useEffect(() => {
    const fetchChildDetails = async () => {
      const user_id = localStorage.getItem("user_id");
      const response = await axios.get(`${BASE_URL}/children/${user_id}`);
      if (response?.data?.child) {
        setProfile(response.data);
        setBackupProfile(response.data);
      }
    };
    fetchChildDetails();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile((prev) => ({ ...prev, child: { ...prev.child, [name]: value } }));
  };

  const handleEmergencyChange = (e, index, field) => {
    const { value } = e.target;
    const updatedContacts = [...(profile.emergency_contacts || [])];
    updatedContacts[index] = { ...updatedContacts[index], [field]: value };
    setProfile((prev) => ({ ...prev, emergency_contacts: updatedContacts }));
  };

  const handleEdit = () => {
    setBackupProfile(profile);
    setIsEditing(true);
  };

  const handleCancel = () => {
    setProfile(backupProfile);
    setIsEditing(false);
  };

  const handleSave = () => {
    console.log('Saved:', profile);
    setIsEditing(false);
  };

  return (
    <div style={{ minHeight: '80vh', padding: '20px', display: 'flex', justifyContent: 'center' }}>
      <Card className="shadow-sm w-100" style={{ maxWidth: '1200px', borderRadius: '10px' }}>
        <Card.Body>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h4 className="fw-bold mb-0" style={{ color: reusableColor.customTextColor }}>Child Profile</h4>
            {!isEditing ? (
              <Button size="sm" style={{ backgroundColor: reusableColor.customTextColor, border: 'none' }} onClick={handleEdit}>Edit Profile</Button>
            ) : (
              <Button size="sm" variant="secondary" onClick={handleCancel}>Cancel</Button>
            )}
          </div>

          <Row>
            <Col xs={12} md={4} className="border-end mb-4 mb-md-0 text-center">
              <div className="mb-3">
                <div className="position-relative d-inline-block">
                  {profile?.child?.photo_url ? (
                    <img
                      src={profile.child.photo_url}
                      alt="Child"
                      className="rounded-circle"
                      style={{ width: 100, height: 100, objectFit: 'cover', border: '3px solid #2ab7a9' }}
                    />
                  ) : (
                    <FaUserCircle size={90} color="#2ab7a9" className="border rounded-circle bg-white p-1" />
                  )}
                  <div className="position-absolute bottom-0 end-0 bg-white rounded-circle p-1" style={{ border: '2px solid #2ab7a9' }}>
                    <FaCamera size={14} color="#1A2423FF" />
                  </div>
                </div>
                <h6 className="fw-bold mt-2 mb-0">{profile?.child?.full_name}</h6>
                <p className="text-muted">{profile?.child?.role_name}</p>
              </div>

              <Nav className="flex-column">
                {/* {['personal', 'location', 'emergency', 'parents', 'documents', 'classroom'].map((key) => ( */}
                {['personal', 'emergency', 'parents', 'documents', 'classroom'].map((key) => (
                  <Nav.Link key={key} active={activeSection === key} onClick={() => setActiveSection(key)} className="mb-2 rounded"
                    style={{ backgroundColor: activeSection === key ? reusableColor.customTextColor : '', color: activeSection === key ? 'white' : 'black' }}>
                    {key === 'personal' && <FaUser className="me-2" />}
                    {/* {key === 'location' && <FaMapMarkerAlt className="me-2" />} */}
                    {key === 'emergency' && <FaPhone className="me-2" />}
                    {key === 'parents' && <FaUser className="me-2" />}
                    {key === 'documents' && <RiFileUploadFill className="me-2" />}
                    {key === 'classroom' && <RiBook3Fill className="me-2" />}
                    {key.charAt(0).toUpperCase() + key.slice(1).replace('_', ' ')}
                  </Nav.Link>
                ))}
              </Nav>
            </Col>

            <Col xs={12} md={8}>
              <Form>
                {activeSection === 'personal' && (
                  <Card className="mb-3">
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>
                      Personal Information
                    </Card.Header>
                    <Card.Body>
                      <Row className="mb-3">
                        <Col md={6}>
                          <Form.Label>Full Name</Form.Label>
                          <Form.Control name="full_name" value={profile?.child?.full_name || ''} onChange={handleChange} disabled={!isEditing} />
                        </Col>
                      </Row>
                      <Row>
                        <Col md={6}>
                          <Form.Label>Email</Form.Label>
                          <Form.Control name="email" value={profile?.child?.email || ''} onChange={handleChange} disabled={!isEditing} />
                        </Col>
                        <Col md={6}>
                          <Form.Label>Phone</Form.Label>
                          <Form.Control name="user_phone" value={profile?.child?.user_phone || ''} onChange={handleChange} disabled={!isEditing} />
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                )}

                {activeSection === 'location' && (
                  <Card className="mb-3">
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>
                      Location / Classroom
                    </Card.Header>
                    <Card.Body>
                      <Row>
                        <Col md={6}>
                          <Form.Label>Classroom</Form.Label>
                          <Form.Control name="assigned_classroom" value={profile?.child?.assigned_classroom || ''} onChange={handleChange} disabled={!isEditing} />
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                )}

                {activeSection === 'emergency' && profile?.emergency_contacts?.map((contact, index) => (
                  <Card className="mb-3" key={contact.id || index}>
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>
                      Emergency Contact {index + 1}
                    </Card.Header>
                    <Card.Body>
                      <Row>
                        <Col md={6}>
                          <Form.Label>Contact Name</Form.Label>
                          <Form.Control value={contact.name} onChange={(e) => handleEmergencyChange(e, index, 'name')} disabled={!isEditing} />
                        </Col>
                        <Col md={6}>
                          <Form.Label>Contact Phone</Form.Label>
                          <Form.Control value={contact.phone} onChange={(e) => handleEmergencyChange(e, index, 'phone')} disabled={!isEditing} />
                        </Col>
                        <Col md={6}>
                          <Form.Label>Relationship</Form.Label>
                          <Form.Control value={contact.relationship_to_child} onChange={(e) => handleEmergencyChange(e, index, 'relationship_to_child')} disabled={!isEditing} />
                        </Col>
                        <Col md={6}>
                          <Form.Label>Address</Form.Label>
                          <Form.Control value={contact.address} onChange={(e) => handleEmergencyChange(e, index, 'address')} disabled={!isEditing} />
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                ))}

                {activeSection === 'parents' && (
                  <Card className="mb-3">
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Parent Details</Card.Header>
                    <Card.Body>
                      <Row>
                        <Col md={6}>
                          <Form.Label>Mother's Name</Form.Label>
                          <Form.Control name="mother_name" value={profile?.child?.mother_name || ''} onChange={handleChange} disabled={!isEditing} />
                        </Col>
                        <Col md={6}>
                          <Form.Label>Father's Name</Form.Label>
                          <Form.Control name="father_name" value={profile?.child?.father_name || ''} onChange={handleChange} disabled={!isEditing} />
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                )}

                {/* {activeSection === 'documents' && (
                  <Card className="mb-3">
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Documents</Card.Header>
                    <Card.Body>
                      <Form.Group className="mb-3">
                        <Form.Label>Medical Form</Form.Label>
                        <Form.Control type="file" disabled={!isEditing} />
                      </Form.Group>
                    </Card.Body>
                  </Card>
                )} */}
                {activeSection === 'documents' && (
                  <Card className="mb-3">
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Documents</Card.Header>
                    <Card.Body>
                      <Form.Group className="mb-3">
                        <Form.Label>Medical Form</Form.Label>
                        <Form.Control type="file" disabled={!isEditing} />
                        {profile?.documents?.medical_form_url && (
                          <div className="mt-2">
                            <a href={profile.documents.medical_form_url} target="_blank" rel="noopener noreferrer">
                              View Medical Form
                            </a>
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Immunization Record</Form.Label>
                        <Form.Control type="file" disabled={!isEditing} />
                        {profile?.documents?.immunization_record_url && (
                          <div className="mt-2">
                            <a href={profile.documents.immunization_record_url} target="_blank" rel="noopener noreferrer">
                              View Immunization Record
                            </a>
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Lunch Form</Form.Label>
                        <Form.Control type="file" disabled={!isEditing} />
                        {profile?.documents?.lunch_form_url && (
                          <div className="mt-2">
                            <a href={profile.documents.lunch_form_url} target="_blank" rel="noopener noreferrer">
                              View Lunch Form
                            </a>
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Agreement Document</Form.Label>
                        <Form.Control type="file" disabled={!isEditing} />
                        {profile?.documents?.agreement_docs_url && (
                          <div className="mt-2">
                            <a href={profile.documents.agreement_docs_url} target="_blank" rel="noopener noreferrer">
                              View Agreement Document
                            </a>
                          </div>
                        )}
                      </Form.Group>
                    </Card.Body>
                  </Card>
                )}


                {activeSection === 'classroom' && (
                  <Card className="mb-3">
                    <Card.Header className="fw-bold" style={{ backgroundColor: reusableColor.customTextColor, color: 'white' }}>Classroom Assignment</Card.Header>
                    <Card.Body>
                      <Form.Label>Assigned Classroom</Form.Label>
                      <Form.Select name="assigned_classroom" value={profile?.child?.assigned_classroom || ''} onChange={handleChange} disabled={!isEditing}>
                        <option value="">Select a classroom</option>
                        {
                          classroom.map((classroom) => (
                            <option key={classroom.classroom_id} value={classroom.classroom_id}>{classroom.name}</option>
                          ))}
                      </Form.Select>
                    </Card.Body>
                  </Card>
                )}

                {isEditing && (
                  <div className="text-end">
                    <Button onClick={handleSave} style={{ backgroundColor: reusableColor.customTextColor, border: 'none' }}>
                      Save Changes
                    </Button>
                  </div>
                )}
              </Form>
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </div>
  );
};

export default ChildrenProfile;
